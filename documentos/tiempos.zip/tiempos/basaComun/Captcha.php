<?php  session_start();

/* 
 * Captcha simple
 * 
 
//Se genera un string y se acorta a seis caracteres
$ranStr = substr( sha1( microtime() ),0,6);
//Se almacena el valor en una variable de sesión
$_SESSION['key_capt'] = $ranStr;
//Se crea la imagen (esta debe existir)
$imagen = imagecreatefromjpeg( "fondo_captcha.jpg" );

// la funcion imagecolorallocate ( $imagen , rojo , verde , azul ) genera un color
$colortext = imagecolorallocate($imagen, 0, 0, 400);
imagestring($imagen, 5, 30, 8, $ranStr, $colortext);
header( "Content-type: image/jpeg" );
//Se crea la imagen
imagejpeg($imagen); 
*/




/*
 * Captcha complejo
 */
$RandomStr = md5(microtime());
$ResultStr = substr($RandomStr,0,6);
$NewImage =imagecreatefromjpeg("fondo_captcha.jpg");
$LineColor = imagecolorallocate($NewImage,233,255,200);
$TextColor = imagecolorallocate($NewImage, 221, 255, 255);
imageline($NewImage,20,1,40,40,$LineColor);
imageline($NewImage,20,1,80,40,$LineColor);
imageline($NewImage,40,1,40,40,$LineColor);
imageline($NewImage,40,1,80,40,$LineColor);
imageline($NewImage,60,1,60,40,$LineColor);
imageline($NewImage,60,1,100,40,$LineColor);
imageline($NewImage,80,1,60,40,$LineColor);
imageline($NewImage,80,1,100,40,$LineColor);
imageline($NewImage,19,100,120,0,$LineColor);
imageline($NewImage,1,50,rand(1, 100),0,$LineColor);
imageline($NewImage,1,20,rand(1, 100),10,$LineColor);//
imageline($NewImage,1,50,rand(1, 100),20,$LineColor);
imageline($NewImage,1,20,rand(1, 100),30,$LineColor);//
imageline($NewImage,1,50,rand(1, 100),40,$LineColor);
imageline($NewImage,1,20,rand(1, 100),50,$LineColor);//

$font = imageloadfont("comic_sans_ms.gdf");
imagestring ($NewImage, $font, 10, -5, $ResultStr, $TextColor );
$_SESSION['key_capt'] = $ResultStr;  //store the actual result in a Server session
header("Content-type: image/jpeg");
imagejpeg($NewImage);
imagedestroy($NewImage);

?>