<?php

class SAPPagoService  {

    private $sapPagosDAO;

    function __construct() {        
        $this->sapPagosDAO = DAOFactory::getDAO('sappago');
    }
    
    public function buscarByPedido($pedido, $limite){
        return $this->sapPagosDAO->buscarByPedido($pedido,$limite);
    }
    
    public function buscarByProveedor($prov, $limite){
        return $this->sapPagosDAO->buscarByProveedor($prov,$limite);
    }
    
    public function buscarFacturasByPago($comp_pago,$año,$sociedad){
        return $this->sapPagosDAO->buscarFacturas($comp_pago,$año,$sociedad);
    }
    
    public function verPedidoPagado($p_docu){
        return $this->sapPagosDAO->verPedidoPagado($p_docu);
    }
   
}
?>
