<?php

class LoginService  {

    private $proveedorDAO;

    function __construct() {
        
        $this->proveedorDAO = DAOFactory::getDAO('proveedor');
    }

    public function validarUsuario($usuario,$password, $validaContrasena ) {
        //return $this->ejemploDAO->buscarEjemplo($id);    	
        $OUsu = new Proveedor();              
        if ($validaContrasena){
            $OUsu = $this->proveedorDAO->buscarProveedorByCuityPass($usuario,$password);
        }else{
            $OUsu = $this->proveedorDAO->buscarProveedorByCuit($usuario);
        }
                       
        return $OUsu;
    }
    
    public function traerDatosProvSAP($idBPSAP) {
        $prov = new SAPProveedor();
        $proveedorDAO = DAOFactory::getDAO('sapproveedor');
        $prov = $proveedorDAO->buscarById($idBPSAP);                       
        return $prov[0];
    }

    public function validarCUIT($cuit) {        
        $sapproveedorDAO = DAOFactory::getDAO('sapproveedor');        
        $OUsu = new Proveedor();   
        $sapproveedor = $sapproveedorDAO->buscarByCUIT($cuit);        
        if(count($sapproveedor) > 0){        
            $OUsu->setCUIT($sapproveedor[0]->getCUIT());
            $OUsu->setIdSAP($sapproveedor[0]->getIdSap());
            $OUsu->setRazonSoc($sapproveedor[0]->getRazonSoc());
            $OUsu->setEmail($sapproveedor[0]->getEmail());
            $OUsu->setTel($sapproveedor[0]->getTel());            
        }
        
        return $OUsu;
    }
    
    public function validarHashParaCambioDeUsuario($clave) {                
        $OUsu = $this->proveedorDAO->validarHashParaCambioDeUsuario($clave);
        return $OUsu;
    }
    
    public function anularClaveDeCambio($clave) {
        $resultados = $this->proveedorDAO->anularClaveDeCambio($clave);
        return $resultados;
    }
    
    public function buscarClaveDeCambio($clave) {
        $resultados = $this->proveedorDAO->buscarClaveDeCambio($clave);
        return $resultados;
    }
    
    
    public function ingresaClaveDeCambio($cuit) {
        $resultados = $this->proveedorDAO->ingresaClaveDeCambio($cuit);
        return $resultados;
    }
    

    
}
?>