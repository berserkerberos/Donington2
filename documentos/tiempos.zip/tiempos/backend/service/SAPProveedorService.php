<?php

class SAPProveedorService {

    private $sapProvDAO;

    function __construct() {                               
        $this->sapProvDAO = DAOFactory::getDAO('sapproveedor');               
    }

    public function buscarById($id) {
        
        return $this->sapProvDAO->buscarById($id);
    }
    public function buscarByCUIT($cuit){
        
        return $this->sapProvDAO->buscarByCUIT($cuit);
    }

    public function buscarVariosProveedores($idSAPArray){
        return $this->sapProvDAO->buscarVariosProveedores($idSAPArray);
    }
}
?>
