<?php

class ProveedorService  {

    private $proveedor;

    function __construct() {
        $this->proveedor = DAOFactory::getDAO('proveedor');
    }

    public function buscarId($id) {
        
        return $this->proveedor->buscarId($id);
    }

    public function buscarProveedorByCuityPass($cuit, $pass){
        return $this->proveedor->buscarProveedorByCuityPass($cuit, $pass);	
    }
    
    public function buscarProveedorByCuit($cuit){
        return $this->proveedor->buscarProveedorByCuit($cuit);
    }
    
    public function guardarProveedor(Proveedor $proveedor){
        return  $this->proveedor->guardarProveedor($proveedor);
    }
    
    public function buscarClaveDeCambio($clave){
        return  $this->proveedor->buscarClaveDeCambio($clave);
    }
    public function anularClaveDeCambio($clave){
        return  $this->proveedor->anularClaveDeCambio($clave);
    }
    public function ingresaClaveDeCambio($cuit){
        return  $this->proveedor->ingresaClaveDeCambio($cuit);
    }
    public function modificarProveedorClave(Proveedor $proveedor) {
        return  $this->proveedor->modificarProveedorClave($proveedor);
    }
    public function buscarProveedortodos() {
        $resultados = $this->proveedor->buscarProveedortodos();
        return $resultados;
    }
    

}
?>
