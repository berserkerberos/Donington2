<?php

class FacturaService  {

    private $facturaDAO;

    function __construct() {        
    
    }
    
    private function generarMigoYMiro(Factura $factura){
            
        
        $SAPPedidoDAO = DAOFactory::getDAO('sappedido');
        $status_array = array("estado" => "ERROR" , "migo" => "", "miro" => "", "mensajes" => [] );
    
        $iniFile = ROOT_PATH . "/backend/config/configWS.ini";
        $data = parse_ini_file($iniFile, true);
        $usuLogueado = unserialize($_SESSION['USUARIO']);
        
        try {
                              
            $bodyJson = "";
            $url =  $data["migo_miro"]["url"];
            $credenciales =  $data["migo_miro"]["user"] . ":" . $data["migo_miro"]["password"];
            $protocolo =  $data["migo_miro"]["protocolo"];
            
            /* @var $sapPedido SAPPedido **/            
            $sapPedido =  $SAPPedidoDAO->buscarByNroDoc($factura->getFac_pedSap());            
            $datos_det =[];
            $centroSegunDetalle =  "";
            foreach ($sapPedido->getListPedidosDetalle() as $sappedidodetalle ){
                $wsPedDet =    $this->WSCargarPedidoDet(   $sappedidodetalle->getDocumentoComp(),
                    $sappedidodetalle->getPosicion(),
                    utf8_encode( $sappedidodetalle->getDetalle())
                    );
                $centroSegunDetalle =  $sappedidodetalle->getSociedad() ;
                array_push($datos_det, $wsPedDet);
            }
            
            
            $datos_cab  =  $this->WSCargarPedidoCab("0001",
                $centroSegunDetalle,
                date("d-m-Y", strtotime($factura->getFac_fechaEmi())) ,
                $factura->getFac_nroFact(), $factura->getFac_iva(),
                Helper::formatMonedaADecimalMysql($factura->getFac_monto()) , "ARS", $datos_det);
            
            $datos_arr = ["Cabecera" => (object) $datos_cab];            
            $bodyJson = json_encode($datos_arr);    
                        
            $resultado =  Helper::callApiSAP("POST", $protocolo . $credenciales ."@". $url, $bodyJson );            
            $resul_array =  json_decode($resultado);
            $todoLosMensajes =  $resul_array->MigoMiro_Res->MigoMiro->Mensaje;
            $mensajes_array = array();
            
            if( is_array( $todoLosMensajes)){
                foreach ($todoLosMensajes as $msj ){
                    array_push($mensajes_array, $msj->Message);
                }
            }
            if (is_object($todoLosMensajes)){
                array_push($mensajes_array, $todoLosMensajes->Message);
            }
            
            $resul_array_migo = [];
            $resul_array_miro = [];
            
            /*
             $mensajes_array =  json_decode('[
             "Documento de Material número 5000013267/2018 contabilizado correctamente",
             "Factura de Proveedor número 5105609405/2018 contabilizado correctamente"
             ]');
             **/
            
            if(count($mensajes_array) == 2 ){
                
                if (strpos( $mensajes_array[0], "Documento de Material número") !== FALSE){
                    preg_match_all('!\d+!', $mensajes_array[0], $resul_array_migo);
                }
                if (strpos( $mensajes_array[1], "Factura de Proveedor número") !== FALSE){
                    preg_match_all('!\d+!', $mensajes_array[1], $resul_array_miro);
                }
                                
                if(!empty($resul_array_migo) && !empty($resul_array_migo) ){                 
                    if( count( $resul_array_migo[0]) == 2 && count( $resul_array_miro[0]) == 2 ){
                        $status_array["estado"] = "OK";
                        $status_array["migo"] = $resul_array_migo[0][0];
                        $status_array["miro"] = $resul_array_miro[0][0];
                    }
                }else{                    
                    $status_array["estado"] = "ERROR";
                    $status_array["migo"] = "";
                    $status_array["miro"] = "";
                    $status_array["mensajes"] = $mensajes_array;
                }                               
            }else{                
                $status_array["estado"] = "ERROR";
                $status_array["migo"] = "";
                $status_array["miro"] = "";
                $status_array["mensajes"] = $mensajes_array;
            }
                                  
        } catch (Exception $e) {
            throw $e;
        }
        
        if($status_array["estado"] == "ERROR"){
            Helper::logEnArchivos("Error con el usuario: ". $usuLogueado->getCUIT() .", pedido: " . $factura->getFac_pedSap() .", status: " . json_encode($status_array)   , "Error_servicio_migomiro");
        }else{
            Helper::logEnArchivos("Se confirmo usuario: ". $usuLogueado->getCUIT() .", pedido: " . $factura->getFac_pedSap() .", status: " . json_encode($status_array)  , "OK_servicio_migomiro");
        }
            
        return $status_array;
        
    }
    
    public function guardarFactura(Factura $factura)
        //guarda en sap migo y miro y datos de factura en db mysql
        {
        //return $this->ejemploDAO->buscarEjemplo($id);
    	$tmpResul = true;
    	/** @var FacturaDAO $facturaDAO */
        $facturaDAO = DAOFactory::getDAO('factura');
        $resul_array = array("estado" => "ERROR" , "migo" => "", "miro" => "", "mensajes" => []);
        
        $factura->setPendienControl("S");
        
        try {                
            
            if (empty($factura->getFac_anoSap())|| strlen($factura->getFac_anoSap()) > 4 ) {
                throw new Exception("Debe indicar la fecha de la factura correctamente!");
            } 

            $tmpIDFact =  $facturaDAO->guardarFactura($factura);
            if ($tmpIDFact > 0){
                //Helper::printDebugPanel("Termno", "Termino",false,false);
                //exit;
                $resul_array =  $this->generarMigoYMiro($factura);    //jc volver a habilitar y quitar de lo abajo
                /*$resul_array["estado"]  = "OK";
                $resul_array["migo"]  = "100";
                $resul_array["miro"]  = "200";**/
                //jc quitar de lo arriba para produccion
                if ($resul_array["estado"]  == "OK"){
                    
                    $factura->setFac_migoSap($resul_array["migo"]);
                    $factura->setFac_miroSap($resul_array["miro"]);
                    $facturaDAO->actualizaPendienteDeControl($tmpIDFact, "N",$factura);
                }
                
            }else{
                throw new Exception("Error al querer registrar la factura. Vuelva a intentarlo");
            }
          
                                    
        } catch (Exception $e) {
            $resul_array = array("estado" => "ERROR" , "migo" => "", "miro" => "", "mensajes" => [ $e->getMessage()] );            
        }               
        
        return $resul_array;
    }

    public function listarFacturas($idSAP){
        $facturaDAO = DAOFactory::getDAO('factura');
        //validar reglas de negocio si las hay
        $facturas = $facturaDAO->listarFacturas($idSAP);
        return $facturas;
    }
    
    public function listarFacturasPorCentroAlma($centro,$alma,$fechaDesde,$fechaHasta,$estadado,$selectGrupoComp,$cb_cantidad,$provSAPid){
        $facturaDAO = DAOFactory::getDAO('factura');       
        $facturas = $facturaDAO->listarFacturasPorCentroAlma($centro,$alma,$fechaDesde,$fechaHasta,$estadado,$selectGrupoComp,$cb_cantidad,$provSAPid);
        return $facturas;
    }
    
    public function listarEstadosDeFacturas(){
        $facturaDAO = DAOFactory::getDAO('factura');
        $facturas = $facturaDAO->listarEstadosDeFacturas();
        return $facturas;
    }
    
    public function actualizaEstadosDeFactura($facid, $estado){
        $facturaDAO = DAOFactory::getDAO('factura');
        $facturas = $facturaDAO->actualizaEstadosDeFactura($facid, $estado);
        return $facturas;
    }
    
    
    public function buscarFacturaById($id){
        $facturaDAO = DAOFactory::getDAO('factura');
        $factura = $facturaDAO->buscarFacturaById($id);        
        return $factura;
    }
    
    public function buscarFacturaByNroPedido($sapPedido){
        $facturaDAO = DAOFactory::getDAO('factura');
        $factura = $facturaDAO->buscarFacturaByNroPedido($sapPedido);
        return $factura;
    }

    public function buscarFacturaByNroFac($numeroFactura, $provSAPId){
        $facturaDAO = DAOFactory::getDAO('factura');
        $factura = $facturaDAO->buscarFacturaByNroFac($numeroFactura,$provSAPId);
        return $factura;
    }
        
    public function buscarFacFecEmision($facFecDesde, $facFecHasta){
        $facturaDAO = DAOFactory::getDAO('factura');
        //validar reglas de negocio si las hay
        $facturas = $facturaDAO->buscarFacFecEmision($facFecDesde, $facFecHasta);
        return $facturas;
    }      
    
    public function WSCargarPedidoCab($id,$sociedad,$fechaFactura,$nroFactura,$iva,$impFactura,$moneda,$detalle){
        
        $datos_cab  = [
            "ID" => $id,
            "Sociedad" => $sociedad,
            "FechaFactura" => $fechaFactura,
            "NroFactura" => $nroFactura,
            "IVA" => $iva,
            "ImpFactura" => $impFactura,
            "Moneda" => $moneda,
            "Posicion" => $detalle
        ];
        
        return $datos_cab;
    }
    
    
    public function WSCargarPedidoDet($nroPedido,$posicion,$denominacion){
        
        $datos_det =[
            "Pedido" => $nroPedido,
            "Posicion" => $posicion,
            "Denominacion" => $denominacion
        ];
        
        return $datos_det;
    }
         

}
?>