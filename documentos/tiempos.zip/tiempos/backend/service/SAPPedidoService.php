<?php


class SAPPedidoService  {

    private $sapPedidoDAO;

    function __construct() {                              
        $this->sapPedidoDAO = DAOFactory::getDAO('sappedido');
    }
    public function buscarByNroDoc($docu){
        return $this->sapPedidoDAO->buscarByNroDoc($docu);
    }
    public function buscarByProveedorConFactura($prov,$centro,$almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta){
        return $this->sapPedidoDAO->buscarByProveedorConfactura($prov, $centro, $almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta);        
    }                  
    public function buscarByProveedorPendiente($prov,$centro,$almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta){
        return $this->sapPedidoDAO->buscarByProveedorPendiente($prov, $centro, $almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta);
    }                    
    public function buscarByCentroYAlmacenPendientes($centro, $almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta,$prov){
        return $this->sapPedidoDAO->buscarByCentroYAlmacenPendientes($centro, $almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta,$prov);
    }
    public function verEstadoPedido($docu){
        return $this->sapPedidoDAO->verEstadoPedido($docu);   
    }
    public function validaTieneMIGO($docu){
        return $this->sapPedidoDAO->validaTieneMIGO($docu);      
    }
    public function validaFaltaVerFactEM($docu){
        return $this->sapPedidoDAO->validaFaltaVerFactEM($docu);      
    }
    
}
?>
