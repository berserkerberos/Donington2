<?php

class ProveedorDAO extends DAOGeneric  {

    private $result;
    function __construct() {
    
        $iniFile = ROOT_PATH . "/backend/config/configDB.ini";
        $data = parse_ini_file($iniFile, true);
        $con_pdo = "";
        $dsn = "mysql:host=" . $data["DB_EJEMPLO"]["db_string"] . ";dbname=" . $data["DB_EJEMPLO"]["db_name"] ;  
                
        $options = array(  
            PDO::ATTR_PERSISTENT => true,  
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        );  

        try {  
            $con_pdo = new PDO($dsn, $data["DB_EJEMPLO"]["db_usr"] , $data["DB_EJEMPLO"]["db_pass"], $options);  
            $this->db =  $con_pdo;
        }catch (PDOException $e) {            
            Helper::printDebugPanel("Error en la conexión con la DB, ","Error", true, true);
        }          
        
    }

    
    public function guardarProveedor(Proveedor $proveedor) {
        $tmpResul =  false;

        $query = "
        INSERT INTO `PortalProveedores`.`PROVEEDORES`
                    (
                     `PRV_CUIT`,
                     `PRV_CLAVE`,
                     `PRV_IDSAP`,
                     `PRV_RAZONSOCIAL`,
                     `PRV_EMAIL`,
                     `PRV_TELEFONO`,
                     `PRV_TIP_ID`,
                     `PRV_ESTADO`)
        VALUES (
                :PRV_CUIT,
                :PRV_CLAVE,
                :PRV_IDSAP,
                :PRV_RAZONSOCIAL,
                :PRV_EMAIL,
                :PRV_TELEFONO,
                :PRV_TIP_ID,
                :PRV_ESTADO);
            ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        try {
            
            $result->execute(array(
                ':PRV_CUIT' => $proveedor->getCUIT(),
                ':PRV_CLAVE' => $proveedor->getClave(),
                ':PRV_IDSAP' => $proveedor->getIdSAP(),
                ':PRV_RAZONSOCIAL' => $proveedor->getRazonSoc(),
                ':PRV_EMAIL' => $proveedor->getEmail(),
                ':PRV_TELEFONO' => $proveedor->getTel(),
                ':PRV_TIP_ID' => $proveedor->getTipoProveId(),
                ':PRV_ESTADO'  => $proveedor->getEstado()
            ));
            
            $tmpResul =  true;
        } catch (Exception $e) {
            throw $e;
        }
        return $tmpResul;
    }
    
    public function modificarProveedorClave(Proveedor $proveedor) {
        $tmpResul =  false;
        
        $query = "
        UPDATE `PortalProveedores`.`PROVEEDORES`
                SET `PRV_CLAVE` = :PRV_CLAVE, 
                     `PRV_ESTADO` =  :PRV_ESTADO
            WHERE PRV_CUIT = :PRV_CUIT ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        try {
            
            $result->execute(array(
                ':PRV_CLAVE' => $proveedor->getClave(),
                ':PRV_ESTADO'  => $proveedor->getEstado(),
                ':PRV_CUIT' => $proveedor->getCUIT()
            ));
            
            $tmpResul =  true;
        } catch (Exception $e) {
            throw $e;
        }
        return $tmpResul;
    }
    
    
    public function buscarProveedorById($idSAP){
        
        $query = "select * from PROVEEDORES INNER JOIN PROVEEDOR_TIPOS ON PRV_TIP_ID = TIP_ID where PRV_IDSAP = :IDSAP " ;
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':IDSAP' => $idSAP
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        $prov = new Proveedor();
        
        foreach ($arr_resul as $item){
            $prov->setId($item["PRV_ID"]);
            $prov->setClave($item["PRV_CLAVE"]);
            $prov->setCUIT($item["PRV_CUIT"]);
            $prov->setEmail($item["PRV_EMAIL"]);
            $prov->setEstado($item["PRV_ESTADO"]);
            $prov->setIdSAP($item["PRV_IDSAP"]);
            $prov->setRazonSoc($item["PRV_RAZONSOCIAL"]);
            $prov->setTel($item["PRV_TELEFONO"]);
            $prov->setTipoProve($item["TIP_DESCRIPCION"]);
            
        }
        return $prov;
        
    }
    
    public function buscarProveedortodos(){
        
        $query = "select * from PROVEEDORES " ;
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute();
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        $resultado = array();
        
        foreach ($arr_resul as $item){
            $prov = new Proveedor();
            
            $prov->setId($item["PRV_ID"]);
            $prov->setClave($item["PRV_CLAVE"]);
            $prov->setCUIT($item["PRV_CUIT"]);
            $prov->setEmail($item["PRV_EMAIL"]);
            $prov->setEstado($item["PRV_ESTADO"]);
            $prov->setIdSAP($item["PRV_IDSAP"]);
            $prov->setRazonSoc($item["PRV_RAZONSOCIAL"]);
            $prov->setTel($item["PRV_TELEFONO"]);
            $prov->setTipoProve($item["PRV_TIP_ID"]);
            
            array_push($resultado, $prov);
        }
        return $resultado;
        
    }
    
    /*
    public function buscarProveedor($campos, $valores){
        
        $filtro= "";
        $separador= "";
        var_dump($campos);
        exit;
        foreach ($campo as $campos){
            $filtro = $campo;
            $filtro = $filtro . " = '" . $valores . "'";
            $separador = " and ";
        }
        exit;
        $query = "select * from PROVEEDORES " ;
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        $resultado = array();
        
        foreach ($arr_resul as $item){
            $prov = new Proveedor();
            
            $prov->setId($item["PRV_ID"]);
            $prov->setClave($item["PRV_CLAVE"]);
            $prov->setCUIT($item["PRV_CUIT"]);
            $prov->setEmail($item["PRV_EMAIL"]);
            $prov->setEstado($item["PRV_ESTADO"]);
            $prov->setIdSAP($item["PRV_IDSAP"]);
            $prov->setRazonSoc($item["PRV_RAZONSOCIAL"]);
            $prov->setTel($item["PRV_TELEFONO"]);
            $prov->setTipoProve($item["PRV_TIP_ID"]);
            
            array_push($resultado, $prov);
        }
        return $resultado;
        
    }
    **/
    
    public function buscarProveedorByCuityPass($cuit, $pass){

        $query = "select * from PROVEEDORES INNER JOIN PROVEEDOR_TIPOS ON PRV_TIP_ID = TIP_ID where PRV_CUIT = :PRV_CUIT AND PRV_CLAVE = :PRV_CLAVE " ;        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));        
        $result->execute(array(            
            ':PRV_CUIT' => $cuit,
            ':PRV_CLAVE' => $pass,
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
                
        $prov = new Proveedor();
                      
        foreach ($arr_resul as $item){
            
            $query2 = "select AP_CENTRO AS CENTRO , AP_ALMACEN AS ALMACEN from ALMACEN_PROVEEDOR where AP_PRV_ID =  " . $item["PRV_ID"] ;            
            $result = $this->db->prepare($query2, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
            $result->execute();            
            $centroAlmacen = $result->fetchAll(PDO::FETCH_ASSOC);
            $prov->setCentroAlmacenAdmin($centroAlmacen);
            $prov->setId($item["PRV_ID"]);
            $prov->setClave($item["PRV_CLAVE"]);
            $prov->setCUIT($item["PRV_CUIT"]);
            $prov->setEmail($item["PRV_EMAIL"]);
            $prov->setEstado($item["PRV_ESTADO"]);
            $prov->setIdSAP($item["PRV_IDSAP"]);
            $prov->setRazonSoc($item["PRV_RAZONSOCIAL"]);
            $prov->setTel($item["PRV_TELEFONO"]);
            $prov->setTipoProve($item["TIP_DESCRIPCION"]);
            $prov->setTipoProveId($item["TIP_ID"]);
            
        }
        
        return $prov;        
    }
    
    public function buscarProveedorByCuit($cuit){
        
        $query = "select * from PROVEEDORES INNER JOIN PROVEEDOR_TIPOS ON PRV_TIP_ID = TIP_ID where PRV_CUIT = :PRV_CUIT " ;
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':PRV_CUIT' => $cuit,            
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        $prov = new Proveedor();
        
        foreach ($arr_resul as $item){
            
            $query2 = "select AP_CENTRO AS CENTRO , AP_ALMACEN AS ALMACEN from ALMACEN_PROVEEDOR where AP_PRV_ID =  " . $item["PRV_ID"] . " limit  1 ";
            $result = $this->db->prepare($query2, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
            $result->execute();
            $centroAlmacen = $result->fetchAll(PDO::FETCH_ASSOC);
            
            $prov->setCentroAlmacenAdmin($centroAlmacen);
            
            $prov->setId($item["PRV_ID"]);
            $prov->setClave($item["PRV_CLAVE"]);
            $prov->setCUIT($item["PRV_CUIT"]);
            $prov->setEmail($item["PRV_EMAIL"]);
            $prov->setEstado($item["PRV_ESTADO"]);
            $prov->setIdSAP($item["PRV_IDSAP"]);
            $prov->setRazonSoc($item["PRV_RAZONSOCIAL"]);
            $prov->setTel($item["PRV_TELEFONO"]);
            $prov->setTipoProve($item["TIP_DESCRIPCION"]);
            $prov->setTipoProveId($item["TIP_ID"]);
        }
        
        return $prov;
    }

    
    public function buscarProveedorByClaveDeCambio($clave){
        
        $query = "SELECT * FROM `PROVEEDORES` 
                INNER JOIN CLAVES ON CLA_CUIT = `PRV_CUIT` = :PRV_CUIT " ;
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':PRV_CUIT' => $cuit,
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        $prov = new Proveedor();
        
        foreach ($arr_resul as $item){
            $prov->setId($item["PRV_ID"]);
            $prov->setClave($item["PRV_CLAVE"]);
            $prov->setCUIT($item["PRV_CUIT"]);
            $prov->setEmail($item["PRV_EMAIL"]);
            $prov->setEstado($item["PRV_ESTADO"]);
            $prov->setIdSAP($item["PRV_IDSAP"]);
            $prov->setRazonSoc($item["PRV_RAZONSOCIAL"]);
            $prov->setTel($item["PRV_TELEFONO"]);
            $prov->setTipoProve($item["TIP_DESCRIPCION"]);
            $prov->setTipoProveId($item["TIP_ID"]);
        }
        
        return $prov;
    }
 
    
    public function buscarClaveDeCambio($clave){
        
        $query = "SELECT * FROM CLAVES WHERE CLA_CLAVE = :CLA_CLAVE " ;
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':CLA_CLAVE' => $clave,
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
                            
        return $arr_resul;
    }
    
    public function anularClaveDeCambio($clave) {

        $query = "        
            update PortalProveedores.CLAVES
            set CLA_ENUSO = '0' where CLA_CLAVE = :CLA_CLAVE
            ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        try {            
            $result->execute(array(
                ':CLA_CLAVE' => $clave                
            ));
                        
        } catch (Exception $e) {
            throw $e;
        }
        
    }

    
    public function ingresaClaveDeCambio($cuit) {
        $tmpResul = "";
        $query = "
            INSERT INTO CLAVES (CLA_CLAVE,CLA_CUIT, CLA_FECHA_EXPIRA, CLA_ENUSO)
            VALUES (:CLA_CLAVE,:CLA_CUIT, :CLA_FECHA_EXPIRA, :CLA_ENUSO);
            ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        $fecExpira = new DateTime();
        $fecExpira->modify('+3 days');
        
        $clave_tmp =  hash("sha256",$fecExpira->format('Y-m-d H:i:s'));
        
        
        try {
            $result->execute(array(
                ':CLA_CLAVE' => $clave_tmp ,                
                ':CLA_CUIT' => $cuit ,
                ':CLA_FECHA_EXPIRA' => $fecExpira->format('Y-m-d H:i:s') ,
                ':CLA_ENUSO' => 1 
            ));
            $tmpResul = $clave_tmp;
            
        } catch (Exception $e) {
            throw $e;
        }
        return $clave_tmp;        
    }
    

}

?>
