<?php

class SAPPagoDAO extends DAOGeneric {
    
    private $result;
    
    private $mandante;
    
    /**
     * @return mixed
     */
    public function getMandante()
    {
        return $this->mandante;
    }
    
    /**
     * @param mixed $mandante
     */
    public function setMandante($mandante)
    {
        $this->mandante = $mandante;
    }
      
    function __construct() {
        
        $iniFile = ROOT_PATH . "/backend/config/configDBSAP.ini";
        $data = parse_ini_file($iniFile, true);
        $con = "";
        
        $dsn = "Driver=".$data["DB_EJEMPLO"]["db_driver"].";ServerNode=" . $data["DB_EJEMPLO"]["db_string"] . ";Database=" . $data["DB_EJEMPLO"]["db_name"] ;
        $this->setMandante($data["DB_EJEMPLO"]["db_mandante"]);
        try {
            $con = odbc_connect($dsn, $data["DB_EJEMPLO"]["db_usr"] , $data["DB_EJEMPLO"]["db_pass"],SQL_CUR_USE_ODBC);
            $this->db =  $con;
        }catch (PDOException $e) {
            Helper::printDebugPanel("Error en la conexión con la DB, ","Error", true, true);
        }
        
    }
                
    private  function buscarPagos($p_proveedor, $limite){
        //fintrar los proveedores que esten de baja
        
        /*
                
            SAPABAP1.BSEG.DMBTR,
            SAPABAP1.bseg.AUGDT, 
            SAPABAP1.bseg.AUGBL,
            SAPABAP1.bseg.SHKZG,
                        
            SAPABAP1.BSE_CLR.DMBTR ,
            SAPABAP1.BSE_CLR.DIFHW,
            SAPABAP1.BSEG.REBZG,
            SAPABAP1.BKPF.XREVERSING,
            SAPABAP1.BSE_CLR.GJAHR_CLR,
            SAPABAP1.bseg.belnr AS bseg_belnr,
            BKPF2.XREVERSING            
                 
        **/
       
        $sql = "

            SELECT 
            
            SAPABAP1.BSE_CLR.BUKRS_CLR,            
            SAPABAP1.BSE_CLR.GJAHR_CLR,
            case when (SAPABAP1.bseg.AUGBL <> '') then 'SI' else 'NO' end compensa,
            SAPABAP1.BSE_CLR.BELNR_CLR,            
            BKPF2.bldat AS FECHA_PAGO,
            CASE WHEN SAPABAP1.bkpf.XBLNR = '' then '0' else SAPABAP1.bkpf.XBLNR end as XBLNR,                
            SAPABAP1.bkpf.bldat AS FECHA_FACTURA,              
            SAPABAP1.BKPF.BLART,
            CASE WHEN  SAPABAP1.bseg.SHKZG = 'S' then 
                    (SAPABAP1.BSE_CLR.DMBTR + SAPABAP1.BSE_CLR.DIFHW) * -1
                else  
                    (SAPABAP1.BSE_CLR.DMBTR + SAPABAP1.BSE_CLR.DIFHW)  end  AS PAGO,
            case when (BSE_CLR.CLRIN <> '') then 'SI' else 'NO' end as CLRIN ,
            SAPABAP1.bseg.AUGBL
            FROM SAPABAP1.BSE_CLR 
            inner join  SAPABAP1.bseg on SAPABAP1.BSE_CLR.belnr =  SAPABAP1.bseg.belnr
                                             and SAPABAP1.BSE_CLR.gjahr = SAPABAP1.bseg.gjahr
                                             and SAPABAP1.BSE_CLR.BUKRS = SAPABAP1.bseg.BUKRS
                                             AND SAPABAP1.BSE_CLR.BUZEI = SAPABAP1.bseg.BUZEI
            
            left outer join SAPABAP1.bkpf on SAPABAP1.bkpf.belnr =  SAPABAP1.bseg.belnr
                                             and SAPABAP1.bkpf.gjahr = SAPABAP1.bseg.gjahr
                                             and SAPABAP1.bkpf.BUKRS = SAPABAP1.bseg.BUKRS
                                             AND SAPABAP1.BSEG.KOART = 'K'
            left outer join SAPABAP1.bkpf as bkpf2 on bkpf2.belnr =  SAPABAP1.bse_clr.belnr_clr
                                             and bkpf2.gjahr = SAPABAP1.bse_clr.gjahr_clr
                                             and bkpf2.BUKRS = SAPABAP1.bse_clr.BUKRS                                 

            WHERE
            SAPABAP1.BSEG.MANDT = '" . $this->getMandante() . "' 
            AND SAPABAP1.BSE_CLR.MANDT = '" . $this->getMandante() . "' 
            AND SAPABAP1.BKPF.MANDT = '" . $this->getMandante() . "' 
           
            AND (SAPABAP1.bseg.AUGBL <> '' OR SAPABAP1.BSE_CLR.CLRIN = '2')
            AND SAPABAP1.BSE_CLR.BELNR_CLR IS NOT NULL            
            AND BKPF2.XREVERSING <> 'X' 
            AND SAPABAP1.BSE_CLR.BELNR_CLR NOT IN ( 
                                                    SELECT BKPF3.STBLG  
                                                    FROM SAPABAP1.BKPF as BKPF3
                                                    left outer join SAPABAP1.BSEG as BSEG3 on BKPF3.belnr =  BSEG3.belnr
                                                                                     and BKPF3.gjahr = BSEG3.gjahr
                                                                                     and BKPF3.BUKRS = BSEG3.BUKRS
                                                                                     AND BSEG3.KOART = 'K'                    
                                                    WHERE BKPF3.XREVERSING = 'X'
                                                    AND BSEG3.LIFNR = '". $p_proveedor ."'
                                                    ) 
            
            AND SAPABAP1.BSEG.LIFNR = '". $p_proveedor ."'
            ";
        
        
       
        
        $sql = "select BELNR_CLR, MAX(FECHA_PAGO) AS FECHA_PAGO, sum(PAGO) AS PAGO, CLRIN,
                BUKRS_CLR,GJAHR_CLR 
             from (
                    ".$sql."
            ) group by  BELNR_CLR,  CLRIN, BUKRS_CLR,GJAHR_CLR ";
        
        $sql.=" 
        ORDER BY FECHA_PAGO DESC ,BELNR_CLR DESC         
        " ;
        
        if (!empty($limite)) {
            $sql.=" LIMIT " . $limite;
        }
            
        
        
        $result = odbc_exec($this->db, $sql);
        
        //Helper::printDebugPanel($sql, "consulta", false,false);
        //exit;
        //odbc_result_all($result,"class=table border=1");        
               
        $resultados = array();                
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{            
            while ($item = odbc_fetch_array($result)){            
                $resultados[] = $item;
            }
        }

        return $resultados;
    }      
    
    public function buscarFacturas($comp_pago,$año,$sociedad){
     
        $sql = "
            
            SELECT
            
            case when (SAPABAP1.bseg.AUGBL <> '') then 'SI' else 'NO' end compensa,
            SAPABAP1.BSE_CLR.BELNR_CLR,
            BKPF2.bldat AS FECHA_PAGO,
            CASE WHEN SAPABAP1.bkpf.XBLNR = '' then '0' else SAPABAP1.bkpf.XBLNR end as XBLNR,
            SAPABAP1.bkpf.bldat AS FECHA_FACTURA,
            SAPABAP1.BKPF.BLART,
            CASE WHEN  SAPABAP1.bseg.SHKZG = 'S' then
                    (SAPABAP1.BSE_CLR.DMBTR + SAPABAP1.BSE_CLR.DIFHW) * -1
                else
                    (SAPABAP1.BSE_CLR.DMBTR + SAPABAP1.BSE_CLR.DIFHW)  end  AS PAGO,
            case when (BSE_CLR.CLRIN <> '') then 'SI' else 'NO' end as CLRIN ,
            SAPABAP1.bseg.AUGBL,
            SAPABAP1.BSE_CLR.BUKRS,
            SAPABAP1.BSE_CLR.BUZEI,
            SAPABAP1.bkpf.GJAHR

            FROM SAPABAP1.BSE_CLR
            inner join  SAPABAP1.bseg on SAPABAP1.BSE_CLR.belnr =  SAPABAP1.bseg.belnr
                                             and SAPABAP1.BSE_CLR.gjahr = SAPABAP1.bseg.gjahr
                                             and SAPABAP1.BSE_CLR.BUKRS = SAPABAP1.bseg.BUKRS
                                             AND SAPABAP1.BSE_CLR.BUZEI = SAPABAP1.bseg.BUZEI
            
            left outer join SAPABAP1.bkpf on SAPABAP1.bkpf.belnr =  SAPABAP1.bseg.belnr
                                             and SAPABAP1.bkpf.gjahr = SAPABAP1.bseg.gjahr
                                             and SAPABAP1.bkpf.BUKRS = SAPABAP1.bseg.BUKRS
                                             AND SAPABAP1.BSEG.KOART = 'K'
            left outer join SAPABAP1.bkpf as bkpf2 on bkpf2.belnr =  SAPABAP1.bse_clr.belnr_clr
                                             and bkpf2.gjahr = SAPABAP1.bse_clr.gjahr_clr
                                             and bkpf2.BUKRS = SAPABAP1.bse_clr.BUKRS
            
            WHERE
            SAPABAP1.BSEG.MANDT = '" . $this->getMandante() . "'
            AND SAPABAP1.BSE_CLR.MANDT = '" . $this->getMandante() . "'
            AND SAPABAP1.BKPF.MANDT = '" . $this->getMandante() . "'
                
            AND (SAPABAP1.bseg.AUGBL <> '' OR SAPABAP1.BSE_CLR.CLRIN = '2')
            AND SAPABAP1.BSE_CLR.BELNR_CLR IS NOT NULL
            AND BKPF2.XREVERSING <> 'X'
          
                                                        
            AND  SAPABAP1.BSE_CLR.BELNR_CLR = '". $comp_pago ."'
            AND  SAPABAP1.bkpf.gjahr = '". $año ."'
            AND  SAPABAP1.BSE_CLR.BUKRS = '". $sociedad ."'

        
            ";
        
        
        $sql.="
        ORDER BY FECHA_PAGO DESC ,BELNR_CLR DESC
        " ;
        
        if (!empty($limite)) {
            $sql.=" LIMIT " . $limite;
        }
        
        
        
        $result = odbc_exec($this->db, $sql);
        
        //Helper::printDebugPanel($sql, "consulta", false,false);
        //exit;
        //odbc_result_all($result,"class=table border=1");
        
        $resultados = array();
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{
            while ($item = odbc_fetch_array($result)){
                $resultados[] = $item;
            }
        }
        
        return $resultados;
        
    }
       
    public function buscarByPedido($pedido, $limite){
        //return $this->buscarPagos("",  $prov, $limite ,"","") ;
    }
    
    public function buscarByProveedor($prov, $limite){
        return $this->buscarPagos($prov, $limite ) ;
    }
        
    public function verPedidoPagado($p_docu){        
              
        
        $sql = "";         
        $filtro = "";
        $filtro = (!empty($p_docu) ? "AND SAPABAP1.EKKO.EBELN = " . $p_docu :"");        
        
        if (!empty($filtro)) {
            $sql.= $filtro;
        }else{
            throw new Exception("No se cargo ningun filtro de busqueda");
        }
                   
        $result = odbc_exec($this->db, $sql);
        
        //print del resultado para debug
        //odbc_result_all($result,"class=table border=1");
        
        $resultados = array();                
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{            
            while ($item = odbc_fetch_object($result)){                                         
                array_push($resultados, $item);
            }
        }
        return $resultados;       
    }       

}

?>
