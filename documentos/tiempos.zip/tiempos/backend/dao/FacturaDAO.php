<?php


class FacturaDAO extends DAOGeneric {
    
    private $result;
    function __construct() {
        
        $iniFile = ROOT_PATH . "/backend/config/configDB.ini";
        $data = parse_ini_file($iniFile, true);
        $con_pdo = "";
        $dsn = "mysql:host=" . $data["DB_EJEMPLO"]["db_string"] . ";dbname=" . $data["DB_EJEMPLO"]["db_name"] ;
        
        $options = array(
            PDO::ATTR_PERSISTENT => true,
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        );
        
        try {
            $con_pdo = new PDO($dsn, $data["DB_EJEMPLO"]["db_usr"] , $data["DB_EJEMPLO"]["db_pass"], $options);
            $this->db =  $con_pdo;
            
            if(empty($con_pdo)){
                throw new Exception("No se pudo inicializar el objeto PDO, verifique la conexion a la DB");
            }
            
        }catch (PDOException $e) {
            Helper::printDebugPanel("Error en la conexión con la DB, ","Error", true, true);
        }
        
    }
    
    public function guardarFactura(Factura $factura) {
        
        // if ($this->validarFactura()){
        
        $query = "
                    INSERT INTO FACTURAS_CAB (
                        FAC_PEDSAP,FAC_YEARSAP,FAC_TIPOFAC,
                        FAC_NROFAC,FAC_FECHAEMI,FAC_TOTAL,FAC_PRV_IDSAP,
                        FAC_CAE,FAC_EST_ID,FAC_MIGOSAP,
                        FAC_MIROSAP,FAC_OBS,FAC_IVA
                    )
                        VALUES (
                    :FAC_PEDSAP,:FAC_YEARSAP,:FAC_TIPOFAC,
                    :FAC_NROFAC,:FAC_FECHAEMI,:FAC_TOTAL,:FAC_PRV_IDSAP,
                    :FAC_CAE,:FAC_EST_ID,:FAC_MIGOSAP,
                    :FAC_MIROSAP,:FAC_OBS,:FAC_IVA
                    )";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        try {
            
            //TODO: probar transacciones para guardar el cab de factura
            //          los archivos
            //          los detalless de la factura
            //$this->db->beginTransaction();
            $result->execute(array(
                
                ':FAC_PEDSAP' => $factura->getFac_pedSap() ,
                ':FAC_YEARSAP' => $factura->getFac_anoSap() ,
                ':FAC_TIPOFAC' => $factura->getFac_TipoFac() ,
                ':FAC_NROFAC' => $factura->getFac_nroFact() ,
                ':FAC_FECHAEMI' => $factura->getFac_fechaEmi() ,
                ':FAC_TOTAL' => Helper::formatMonedaADecimalMysql($factura->getFac_monto()) ,
                ':FAC_PRV_IDSAP' => $factura->getFac_provSap() ,
                ':FAC_CAE' => $factura->getFac_cae() ,
                //':FAC_ADJUNTO' => $factura->getFac_adjunto() ,
                ':FAC_EST_ID' => $factura->getFac_estado() ,
                ':FAC_MIGOSAP' => $factura->getFac_migoSap() ,
                ':FAC_MIROSAP' => $factura->getFac_miroSap() ,
                ':FAC_OBS' => $factura->getFac_observac() ,
                ':FAC_IVA' => $factura->getFac_iva() ,
                
            ));
            
            $tmpfactura = $this->buscarFacturaByNroPedido($factura->getFac_pedSap());
            if(empty( $tmpfactura->getFac_id())){
                throw new Exception("Error al intentar cargar la cab de factura");
            }
            $this->cargarDetalleDeFactura($factura->getLisSapPedidoDetalle(), $tmpfactura->getFac_id());
            $this->cargarArchivos($factura->getFac_adjunto(), $tmpfactura->getFac_id());
            //$this->db->commit();
            return $tmpfactura->getFac_id();
            
        } catch (Exception $e) {
            //$this->db->rollBack();
            Helper::logEnArchivos("Error con la factura: ".  var_export($factura,true) . "\n".  json_encode($e)  , "Error_guardarFactura");
            throw $e;
            
        }
        
        //  }
        
    }
    
    private function cargarDetalleDeFactura($detalle,$facid){
        
        foreach ($detalle as $sappeddet){
            
            /* @var $sappeddet SAPPedidoDetalle  **/
            $query = "
            INSERT INTO PortalProveedores.FACTURAS_PEDIDOS
            (FAP_FAC_ID, FAP_POSICION, FAP_CEN_ID,
             FAP_ALM_ID, FAP_DETALLE, FAP_CANTIDAD,
			 FAP_PRECIO, FAP_COD_MATERIAL, FAP_CANT_FACTURA)
            VALUES (:FAP_FAC_ID, :FAP_POSICION, :FAP_CEN_ID,
                    :FAP_ALM_ID, :FAP_DETALLE, :FAP_CANTIDAD,
                    :FAP_PRECIO, :FAP_COD_MATERIAL, :FAP_CANT_FACTURA);
            ";
            
            $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
            
            try {
                
                $result->execute(array(
                    ':FAP_FAC_ID' => $facid,
                    ':FAP_POSICION' => $sappeddet->getPosicion(),
                    ':FAP_CEN_ID' => $sappeddet->getSociedad() ,
                    ':FAP_ALM_ID' => $sappeddet->getAlmacen(),
                    ':FAP_DETALLE' => $sappeddet->getDetalle(),
                    ':FAP_CANTIDAD' => $sappeddet->getCantidad(),
                    ':FAP_PRECIO' => $sappeddet->getPrecio(),
                    ':FAP_COD_MATERIAL' => $sappeddet->getCodMaterial(),
                    ':FAP_CANT_FACTURA' => $sappeddet->getCant_facturada()
                    
                ));
                
            } catch (Exception $e) {
                Helper::logEnArchivos("Error con la factura det: ".   var_export($detalle,true) . "\n".
                    json_encode($e)  , "Error_guardarFactura_det");
                throw  $e;
            }
            
        }
        
    }
    
    private function cargarArchivos($archivos,$facid){
        foreach ($archivos as $archivo){
            $query = "
            INSERT INTO PortalProveedores.FACTURAS_ARCHIVOS
            (FAA_FAC_ID, FAA_ARCHIVO, FAA_FECHA , FAA_NOMBRE )
            VALUES (:FAA_FAC_ID, :FAA_ARCHIVO, :FAA_FECHA , :FAA_NOMBRE );
            ";
            $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
            
            try {
                
                $result->execute(array(
                    ':FAA_FAC_ID' => $facid,
                    ':FAA_ARCHIVO' => $archivo["archivo"],
                    ':FAA_FECHA' => date("Y-m-d H:i:s") ,
                    ':FAA_NOMBRE' => $archivo["nombre"]
                ));
                
            } catch (Exception $e) {
                throw  $e;
            }
        }
    }
    
    public function buscarFacturaByNroFac($nrofactuta,$provSAPid){
        
        $query = "select * from FACTURAS_CAB as A
                    inner join ESTADOS on FAC_EST_ID = EST_ID
                    left outer join PROVEEDORES AS P ON A.`FAC_PRV_IDSAP` =  P.`PRV_IDSAP`
                    where 1=1 ";
        
        if (!empty($nrofactuta)){
            $query .= " and FAC_NROFAC = '". $nrofactuta."'";
        }
        if (!empty($provSAPid)){
            $query .= " and FAC_PRV_IDSAP = '". $provSAPid. "'";
        }
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute();
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        $factura = new Factura();
        
        $resultados =  $this->cargarObjFacturas($arr_resul);
        if (count($resultados) > 0){
            $factura = $resultados[0];
        }
        return $factura;
        
    }
    
    public function buscarFacturaByNroPedido($nroPedido){
        
        $query = "select * from FACTURAS_CAB as A
                    inner join ESTADOS on FAC_EST_ID = EST_ID
                    left outer join PROVEEDORES AS P ON A.`FAC_PRV_IDSAP` =  P.`PRV_IDSAP`
                    where FAC_PEDSAP = :FAC_PEDSAP ";
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':FAC_PEDSAP' => $nroPedido
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        $factura = new Factura();
        
        $resultados =  $this->cargarObjFacturas($arr_resul);
        
        if (count($resultados) > 0 ){
            $factura = $resultados[0];
        }
        
        return $factura;
    }
    
    public function buscarFacturaById($id){
        
        $query = "select * from FACTURAS_CAB as A
                left outer join PROVEEDORES AS P ON A.`FAC_PRV_IDSAP` =  P.`PRV_IDSAP`
                where FAC_ID = :FAC_ID ";
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':FAC_ID' => $id
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        $factura = new Factura();
        $resultados =  $this->cargarObjFacturas($arr_resul);
        
        if (count($resultados) > 0){
            $factura = $resultados[0];
        }
        $factura->setFac_adjunto($this->listarArchivosDeFacturas($factura->getFac_id()));
        return $factura;
        
    }
    
    public function buscarFacFecEmision($facFecDesde, $facFecHasta){
        
        $query = "select * from FACTURAS_CAB as A
                    INNER JOIN PROVEEDORES AS P ON A.`FAC_PRV_IDSAP` =  P.`PRV_IDSAP`
                    where FAC_FECHAEMI >= :fec_desde and FAC_FECHAEMI <= :fec_hasta ";
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':fec_desde' => $facFecDesde,
            ':fec_hasta' => $facFecHasta
        ));
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        return $this->cargarObjFacturas($arr_resul);
    }
    
    public function listarFacturas($idSAP){
        
        $query = "select * from FACTURAS_CAB as A
                 INNER JOIN PROVEEDORES AS P ON A.`FAC_PRV_IDSAP` =  P.`PRV_IDSAP`
                where FAC_PRV_IDSAP = :FAC_PRV_IDSAP ";
        $query .= " ORDER BY FAC_ID DESC ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute(array(
            ':FAC_PRV_IDSAP' => $idSAP
        ));
        
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        $resultado = array();
        
        $resultado = $this->cargarObjFacturas($arr_resul);
        
        return $resultado;
    }
    
    public function listarEstadosDeFacturas(){
        $query = "select * from ESTADOS ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute();
        
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        return $arr_resul;
    }
    
    public function listarArchivosDeFacturas($facturaID){
        $query = "select * from FACTURAS_ARCHIVOS where FAA_FAC_ID = " . $facturaID;
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        $result->execute();
        
        $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
        
        return $arr_resul;
    }
    
    public function actualizaEstadosDeFactura($facid, $estado){
        
        $tmpResul =  false;
        
        $query = "
            UPDATE `PortalProveedores`.`FACTURAS_CAB`
                SET `FAC_EST_ID` = :FAC_EST_ID
            WHERE FAC_ID = :FAC_ID ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        try {
            
            $result->execute(array(
                ':FAC_ID' => $facid,
                ':FAC_EST_ID' => $estado
            ));
            
            $tmpResul =  true;
        } catch (Exception $e) {
            throw $e;
        }
        return $tmpResul;
        
    }
    
    public function actualizaPendienteDeControl($facid, $estado, $factura){
        
        $tmpResul =  false;
        
        $query = "
            UPDATE `PortalProveedores`.`FACTURAS_CAB`
                SET `FAC_PEND_CTRL` = :FAC_PEND_CTRL
                , `FAC_MIGOSAP` = :FAC_MIGOSAP
                , `FAC_MIROSAP` = :FAC_MIROSAP
            WHERE FAC_ID = :FAC_ID ";
        
        $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
        
        try {
            
            $result->execute(array(
                ':FAC_ID' => $facid,
                ':FAC_MIGOSAP' => $factura->getFac_migoSap(),
                ':FAC_MIROSAP' => $factura->getFac_miroSap(),
                ':FAC_PEND_CTRL' => 'N',
            ));
            
            $tmpResul =  true;
        } catch (Exception $e) {
            throw $e;
        }
        return $tmpResul;
        
    }
    
    public function listarFacturasPorCentroAlma($centro,$almacen,$fechaDesde,$fechaHasta,$estado,
        $selectGrupoComp,$cb_cantidad,$proveedorSAP){
            $query = "
                SELECT A.*
                FROM FACTURAS_CAB AS A
                
                WHERE 1=1 ";
            
            
            if (!empty($centro) && !empty($almacen)){
                $query .= "
                    
                AND FAC_ID IN (
                	SELECT `FAP_FAC_ID` FROM FACTURAS_PEDIDOS
                	WHERE FAP_CEN_ID = '".$centro."' AND FAP_ALM_ID = '".$almacen."'
                )
             ";
            }
            
            if(!empty($fechaDesde) && !empty($fechaHasta)){
                $query .= " and  (FAC_FECHAEMI >= '" . $fechaDesde."' and FAC_FECHAEMI <= '" . $fechaHasta . " 23:59:59')";
            }
            if(!empty($estado)){
                $query .= " and FAC_EST_ID =  " . $estado;
            }
            if(!empty($proveedorSAP)){
                $proveedorSAP = intval($proveedorSAP);
                $proveedorSAP = str_pad($proveedorSAP,10,"0",STR_PAD_LEFT);
                $query .= " and FAC_PRV_IDSAP =  " . $proveedorSAP;
            }
            if(!empty($selectGrupoComp)){
                //TODO: pendiente agregar el grupo de compra y el financiador a la tabla de facturas
                //$query .= " and FAC_GRUCOMP =  " . $selectGrupoComp;
            }
            $query .= " ORDER BY FAC_ID DESC ";
            if(!empty($cb_cantidad) ){
                $query .= " LIMIT " . $cb_cantidad;
            }
            $result = $this->db->prepare($query, array(PDO::ATTR_CURSOR => PDO::CURSOR_FWDONLY));
            
            /*
             $tmpArr = array(
             ':CENTRO' => $centro,
             ':ALMA' => $almacen
             );**/
            
            //$result->execute($tmpArr);
            $result->execute();
            $arr_resul = $result->fetchAll(PDO::FETCH_ASSOC);
            $resultado = array();
            
            $resultado = $this->cargarObjFacturas($arr_resul);
            
            return $resultado;
    }
    
    private function cargarObjFacturas($arr_resul){
        
        $resultado = array();
        $arrayPrv_idSAP = [];
        foreach ($arr_resul as $item){
            $factura = new Factura();
            
            $arrayPrv_idSAP[] = $item["FAC_PRV_IDSAP"];
            $factura->setFac_id($item["FAC_ID"]);
            $factura->setFac_pedSap($item["FAC_PEDSAP"]);
            $factura->setFac_anoSap($item["FAC_YEARSAP"]);
            $factura->setFac_TipoFac($item["FAC_TIPOFAC"]);
            $factura->setFac_nroFact($item["FAC_NROFAC"]);
            $factura->setFac_fechaEmi($item["FAC_FECHAEMI"]);
            $factura->setFac_monto($item["FAC_TOTAL"]);
            $factura->setFac_provSap($item["FAC_PRV_IDSAP"]);
            $factura->setFac_cae($item["FAC_CAE"]);
            //$factura->setEstadoDesc($item["EST_DESCRIPCION"]);
            $factura->setFac_estado($item["FAC_EST_ID"]);
            $factura->setFac_migoSap($item["FAC_MIGOSAP"]);
            $factura->setFac_miroSap(($item["FAC_MIROSAP"] == "" ? (1000000000  + $item["FAC_ID"]) : $item["FAC_MIROSAP"]));
            $factura->setFac_observac($item["FAC_OBS"]);
            $factura->setFac_fecIngreso($item["FAC_FEC_ING"]);
            $factura->setFac_iva($item["FAC_IVA"]);
            array_push($resultado, $factura);
        }
        
        $arrObjPrv = [];
        $proveedorDAO = DAOFactory::getDAO('sapproveedor');
        $arrObjPrv = $proveedorDAO->buscarVariosProveedores($arrayPrv_idSAP);
        //Helper::dd($arrObjPrv, "obj prov");
        
        foreach ($resultado as $fac){
            foreach ($arrObjPrv as $prov){
                if($fac->getFac_provSap() == $prov->getIdSAP()){
                    $fac->setProveedorObj($prov);
                    $fac->setFac_provSapDesc($prov->getRazonSoc() . " - " . $prov->getIdSAP());
                }
            }
        }
        
        return $resultado;
    }
}

?>
