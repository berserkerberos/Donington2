<?php

class SAPPedidoDAO extends DAOGeneric {
    
    private $result;
    
    private $mandante;
    
    /**
     * @return mixed
     */
    public function getMandante()
    {
        return $this->mandante;
    }
    
    /**
     * @param mixed $mandante
     */
    public function setMandante($mandante)
    {
        $this->mandante = $mandante;
    }
      
    function __construct() {
        
        $iniFile = ROOT_PATH . "/backend/config/configDBSAP.ini";
        $data = parse_ini_file($iniFile, true);
        $con = "";
        
        $dsn = "Driver=".$data["DB_EJEMPLO"]["db_driver"].";ServerNode=" . $data["DB_EJEMPLO"]["db_string"] . ";Database=" . $data["DB_EJEMPLO"]["db_name"] ;
        $this->setMandante($data["DB_EJEMPLO"]["db_mandante"]);
        try {
            $con = odbc_connect($dsn, $data["DB_EJEMPLO"]["db_usr"] , $data["DB_EJEMPLO"]["db_pass"],SQL_CUR_USE_ODBC);
            $this->db =  $con;
        }catch (PDOException $e) {
            Helper::printDebugPanel("Error en la conexión con la DB, ","Error", true, true);
        }
        
    }
    //TODO: poner en un archivo de configuracion los filtros fijos como mandantes  y grupos de compra
    
    private function buscarDetallePedido($p_documento,$p_posicion){

        $sql = "SELECT
            EBELN,
            EBELP,
            WERKS,
            LGORT,                                   
            MENGE,            
            TXZ01,
            AEDAT,
            MATKL,
            MATNR,
            NETPR,
            
            (
                SELECT  
                SUM( EKBE.BPMNG) 
                FROM  SAPABAP1.EKBE        
                WHERE SAPABAP1.EKBE.EBELN = SAPABAP1.EKPO.EBELN
                        AND SAPABAP1.EKBE.EBELP = SAPABAP1.EKPO.EBELP
                        AND SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "'
                        AND EKBE.VGABE = '1'
                        AND EKBE.SHKZG = 'S'
                GROUP BY EKBE.EBELN, EKBE.EBELP
                
            ) 
                -
            (   
                SELECT  
                SUM( EKBE.BPMNG) 
                FROM  SAPABAP1.EKBE        
                WHERE SAPABAP1.EKBE.EBELN = SAPABAP1.EKPO.EBELN
                        AND SAPABAP1.EKBE.EBELP = SAPABAP1.EKPO.EBELP
                        AND SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "'
                        AND EKBE.VGABE = '1'
                        AND EKBE.SHKZG = 'H'
                GROUP BY EKBE.EBELN, EKBE.EBELP
                
            ) as CANT_ENTREGADA,
            (

                SELECT  
                SUM( EKBE.BPMNG) 
                FROM  SAPABAP1.EKBE        
                WHERE SAPABAP1.EKBE.EBELN = SAPABAP1.EKPO.EBELN
                        AND SAPABAP1.EKBE.EBELP = SAPABAP1.EKPO.EBELP
                        AND SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "'
                        AND EKBE.VGABE = '2'
                        AND EKBE.SHKZG = 'S'
                GROUP BY EKBE.EBELN, EKBE.EBELP

            ) as CANT_FACTURADA              
            FROM SAPABAP1.EKPO 
            WHERE SAPABAP1.EKPO.MANDT = '" . $this->getMandante() . "'   
            AND SAPABAP1.EKPO.LOEKZ NOT IN ('L','S')         

            ";               
        
        
        // TODO: filtrar las posiciones que estan bloqueadas  y marcadas para borrar
        $filtro = (!empty($p_documento) ? "AND SAPABAP1.EKPO.EBELN = " . $p_documento :"");
        $filtro .= (!empty($p_posicion) ? "AND SAPABAP1.EKPO.EBELP = '" . $p_posicion."'":" ");
        
        if (!empty($filtro)) {
            $sql.= $filtro;
        }else{
            throw new Exception("No se cargo ningun filtro de busqueda");
        }               
        
        
        $result = odbc_exec($this->db, $sql);
        //print del resultado para debug
        //odbc_result_all($result,"class=table border=1");
        $resultados = array();
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{
            while ($item = odbc_fetch_array($result)){
                $ped = new SAPPedidoDetalle();
                $ped->setDocumentoComp($item["EBELN"]);
                $ped->setPosicion($item["EBELP"]);
                $ped->setSociedad($item["WERKS"]);
                $ped->setAlmacen($item["LGORT"]);
                $ped->setCantidad($item["MENGE"]);                
                $ped->setDetalle($item["TXZ01"]);
                $ped->setPrecio($item["NETPR"]);
                $ped->setCodMaterial($item["MATNR"]);
                $ped->setCant_facturada($item["CANT_FACTURADA"]);
                $ped->setCant_PedDeEntrega($item["MENGE"] - $item["CANT_ENTREGADA"]);
                $ped->setCant_PedDeFactura($item["MENGE"] - $item["CANT_FACTURADA"]);
                
                array_push($resultados, $ped);
            }
        }
        
        return $resultados;
        
    }
          /*        
    private  function buscarPedidos_bk($p_docu, $p_prov, $limite, $centro, $almacen, $conFactura,
        $traerDetalle, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta){
        //fintrar los proveedores que esten de baja
        $campos = "
                EBELN, 
                SAPABAP1.EKKO.BUKRS,
                BUTXT,
                KDATE,
                KDATB,
                ERNAM,
                SAPABAP1.EKKO.LIFNR,
                SAPABAP1.EKKO.EKGRP,
                EKNAM,
                EKORG,
                KPOSN,
                ZZFINANCIADOR
            ";
        $sql = "
            SELECT DISTINCT " . $campos ."                
                , SAPABAP1.PRCD_ELEMENTS.KWERT  as MONTO";                      
        $sql .=" 
                FROM SAPABAP1.EKKO 
                INNER JOIN SAPABAP1.PRCD_ELEMENTS 
                on SAPABAP1.PRCD_ELEMENTS.KNUMV =  SAPABAP1.EKKO.KNUMV
                INNER JOIN SAPABAP1.T001
                on SAPABAP1.EKKO.BUKRS = SAPABAP1.T001.BUKRS
                INNER JOIN SAPABAP1.T024
                ON SAPABAP1.EKKO.EKGRP = SAPABAP1.T024.EKGRP                
            WHERE (
                SAPABAP1.EKKO.MANDT = '" . $this->getMandante() . "'                
                AND SAPABAP1.PRCD_ELEMENTS.CLIENT = '" . $this->getMandante() . "' 
                AND SAPABAP1.T001.MANDT = '" . $this->getMandante() . "' 
                AND SAPABAP1.T024.MANDT = '" . $this->getMandante() . "' )       
            AND SAPABAP1.PRCD_ELEMENTS.KPOSN  <> '000000'
            AND SAPABAP1.PRCD_ELEMENTS.KSCHL in  ('PBXX','RB00','PB00')
            
            AND CONCAT(SAPABAP1.EKKO.EBELN, RIGHT(SAPABAP1.PRCD_ELEMENTS.KPOSN,5)) NOT IN (
                    SELECT CONCAT(SAPABAP1.EKPO.EBELN, SAPABAP1.EKPO.EBELP)
                    FROM SAPABAP1.EKPO
                    INNER JOIN SAPABAP1.EKKO ON SAPABAP1.EKKO.EBELN = EKPO.EBELN                    
                    AND SAPABAP1.EKPO.LOEKZ IN ('L','S')
                    AND SAPABAP1.EKKO.MANDT = '" . $this->getMandante() . "'
                    AND SAPABAP1.EKPO.MANDT = '" . $this->getMandante() . "'
                    AND SAPABAP1.EKKO.EKGRP  IN ('S13', 'S01','S03','S04' )
                    ".(!(empty($grupoDeCompra)) ? " AND SAPABAP1.EKKO.EKGRP = '".$grupoDeCompra."'  ":"")."
                    AND SAPABAP1.EKKO.FRGRL  <> 'X'                    
            )
            
            AND SAPABAP1.EKKO.EKGRP  IN ('S13', 'S01','S03','S04' )
            ".(!(empty($grupoDeCompra)) ? " AND SAPABAP1.EKKO.EKGRP = '".$grupoDeCompra."'  ":"")."
            AND SAPABAP1.EKKO.FRGRL  <> 'X'              
            ";
        
        // TODO: filtrar las cabeceras que tengan todas  las posiciones  bloqueadas y marcadas para borrar
        $filtro = (!empty($p_docu) ? "AND SAPABAP1.EKKO.EBELN = " . $p_docu :"");
        $filtro .= (!empty($p_prov) ? "AND SAPABAP1.EKKO.LIFNR = '" . $p_prov."'":" ");        

        // con o sin factura dependiendo de $conFactura
        if(!empty($conFactura)){
            
            $filtro .=  " AND SAPABAP1.EKKO.EBELN   in (               
                SELECT SAPABAP1.EKBE.EBELN FROM SAPABAP1.EKBE          
            WHERE SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "'                
            AND SAPABAP1.EKBE.BEWTP  IN ( 'Q', 'T')    )";            
        }else{

            $filtro .=  " AND ( 
                                    SAPABAP1.EKKO.EBELN  not in (               
                                        SELECT SAPABAP1.EKBE.EBELN FROM SAPABAP1.EKBE          
                                        WHERE SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "'                
                                        AND SAPABAP1.EKBE.BEWTP  IN ( 'Q', 'T')  
                                    )
                                OR  SAPABAP1.EKKO.EBELN  not in (
                                        SELECT SAPABAP1.EKBE.EBELN FROM SAPABAP1.EKBE          
                                    WHERE SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "' 
                                    )                
                            )  ";            
        }
        
        //todos los detalles por centro y almacen
        if (!empty($p_almacen)) {

            $filtro .= " and SAPABAP1.EKKO.EBELN  in
            (select  SAPABAP1.EKPO.ebeln
                from  SAPABAP1.EKPO                                                                                                         
                where  SAPABAP1.EKPO.MANDT = '" . $this->getMandante() . "'
                and  SAPABAP1.EKPO.bukrs = '". $p_centro ."' and  SAPABAP1.EKPO.lgort = '".$p_almacen."'                    
            )" ;

        }  

        if (!empty($fechaPrestDesde) && !empty($fechaPrestHasta)){
            $filtro .= " AND  KDATB >= '" . str_replace("-", "",   $fechaPrestDesde)  . "'"  ;
            $filtro .= " AND  KDATE <= '" . str_replace("-", "",   $fechaPrestHasta) ."'" ;
        }

        if (!empty($filtro)) {
            $sql.= $filtro;
        }else{
            throw new Exception("No se cargo ningun filtro de busqueda");
        }
        
        $sql.= " GROUP BY  
                " . $campos . " ,SAPABAP1.PRCD_ELEMENTS.KWERT";
                
        $sql.=" ORDER BY  SAPABAP1.EKKO.EBELN DESC, SAPABAP1.PRCD_ELEMENTS.KPOSN " ;
        
        if (!empty($limite)) {
            $sql.=" LIMIT " . $limite;
        }
        
        $sql =  "select EBELN, 
                    BUKRS,
                    BUTXT,
                    KDATE,
                    KDATB,
                    ERNAM,
                    LIFNR,
                    EKGRP,
                    EKNAM,
                    EKORG,
                    ZZFINANCIADOR
 , sum(L.MONTO) AS MONTO_TOTAL  from (
                ".$sql."
                ) AS L GROUP BY 

            EBELN, 
            BUKRS,
            BUTXT,
            KDATE,
            KDATB,
            ERNAM,
            LIFNR,
            EKGRP,
            EKNAM,
            EKORG,
            ZZFINANCIADOR            
            ";                
       
        
        
        $result = odbc_exec($this->db, $sql);
        //odbc_result_all($result,"class=table border=1");        
        //Helper::dd($sql, "consulta");
        
        $resultados = array();                
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{     
            $cont = 0;
            while ($item = odbc_fetch_array($result)){            
               $cont += 1;
               echo $cont;
               echo "<br>";
               
                $ped = new SAPPedido();        
                
                $ped->setDocumentoComp($item["EBELN"]); 
                $ped->setSociedad($item["BUTXT"]);
                
                $vigenciaDesde = DateTime::createFromFormat('Ymd', $item["KDATB"]);
                $vigenciaHasta = DateTime::createFromFormat('Ymd', $item["KDATE"]);
                
                $ped->setFechaValidacionFinal( $vigenciaDesde->format('d/m') ." a ". $vigenciaHasta->format('d/m') );                
                $ped->setUsuario($item["ERNAM"]);
                $ped->setProveedor($item["LIFNR"]);
                $ped->setOrgCompra($item["EKORG"]);
                $ped->setGruCompra( utf8_encode($item["EKNAM"]));
                $ped->setMontoTotal($item["MONTO_TOTAL"]);                                             
                $ped->setEstaLiberada(true);
                $ped->setFinanciador($item["ZZFINANCIADOR"]);
                
                
                
                $facturaDAO = DAOFactory::getDAO('factura');                                
                $factura =  $facturaDAO->buscarFacturaByNroPedido($item["EBELN"]);                                                               
                $ped->setContabEnPortal( !(empty($factura->getFac_id())) );
                                
                if($traerDetalle){
                    $ped->setListPedidosDetalle($this->buscarDetallePedido($item["EBELN"],""));
                }
                
                if(!empty($conFactura)){
                    $ped->setContabEnSAP("S");
                }else{
                    echo "valida si tiene migo:  " . $item["EBELN"];
                    //$ped->setContabEnSAP($this->validaTieneMIGO($item["EBELN"]));
                }
                
                              
                array_push($resultados, $ped);
                
            }
        }
        
        //Helper::dd($resultados, "resultados");
        echo "Termino";
        exit;
        return $resultados;
    }                  
**/
    private  function buscarPedidos($p_docu, $p_prov, $limite, $centro, $almacen, $conFactura,
        $traerDetalle, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta){
            //fintrar los proveedores que esten de baja
            
            $sql = "
            select a.ebeln
                   ,a.bukrs
                   ,e.butxt
                   ,a.kdate
                   ,a.kdatb
                   ,a.ernam
                   ,a.lifnr
                   ,a.ekgrp
                   ,f.eknam
                   ,a.ekorg
                   ,a.zzfinanciador
                   ,sum(c.kwert) as suma
                   , '".( !empty($conFactura) ? "SI" : "NO" )."' tiene_fac
                   ,a.BEDAT
                   ,g.NAME1
            
                    
            from SAPABAP1.ekko as a
            inner join SAPABAP1.ekpo as b on a.ebeln = b.ebeln
            left join SAPABAP1.prcd_elements as c on a.knumv = c.knumv
                                        and b.ebelp = right(c.kposn,5)
            INNER JOIN SAPABAP1.T001 as e
            ON a.BUKRS = e.BUKRS
            INNER JOIN SAPABAP1.T024 as f
            ON a.EKGRP = f.EKGRP                
            INNER JOIN SAPABAP1.LFA1 as g
            on a.lIFNR = g.lifnr
            
            where C.KPOSN <> '000000'
            and a.MANDT = '" . $this->getMandante() . "'                
            and b.MANDT = '" . $this->getMandante() . "'
            and c.CLIENT = '" . $this->getMandante() . "'              
            and e.MANDT = '" . $this->getMandante() . "'              
            and f.MANDT = '" . $this->getMandante() . "'
            and g.MANDT = '" . $this->getMandante() . "'                                
            and b.loekz = ''
            and a.FRGRL  <> 'X'              
            and c.kschl not in ('ZREC','ZBON','ZBOD')
            and a.EKGRP  IN ('S13', 'S01','S03','S04' )";
    
            if (!empty($grupoDeCompra)) {
                $sql .=" and a.EKGRP = '".$grupoDeCompra."'" ;
            }            
            /*if (!empty($fechaPrestDesde) && !empty($fechaPrestHasta)){
                $sql .= " and  ( a.KDATB >= '" . str_replace("-", "",   $fechaPrestDesde)  . "'"  ;
                $sql .= " AND  a.KDATE <= '" . str_replace("-", "",   $fechaPrestHasta) ."' )" ;
            }**/            
            if (!empty($fechaPrestDesde) && !empty($fechaPrestHasta)){
             $sql .= " and  ( a.BEDAT >= '" . str_replace("-", "",   $fechaPrestDesde)  . "'"  ;
             $sql .= " AND  a.BEDAT <= '" . str_replace("-", "",   $fechaPrestHasta) ."' )" ;
            }                                 
            if (!empty($almacen)) {                
                $sql .= " and  b.bukrs = '". $centro ."' and  b.lgort = '".$almacen."'" ;                
            }            
            // TODO: filtrar las cabeceras que tengan todas  las posiciones  bloqueadas y marcadas para borrar
            $sql .= (!empty($p_docu) ? " and a.EBELN = " . $p_docu :"");
            
            if(!empty($p_prov)){
                $p_prov = intval($p_prov);
                $p_prov = str_pad($p_prov,10,"0",STR_PAD_LEFT);
                $sql .= " and a.LIFNR =  '" . $p_prov . "'";
            }
            
                                                                                   
            $sql .= "
            group by a.ebeln
                   ,a.bukrs
                   ,e.butxt
                   ,a.kdate
                   ,a.kdatb
                   ,a.ernam
                   ,a.lifnr
                   ,a.ekgrp
                   ,f.eknam
                   ,a.ekorg
                   ,a.zzfinanciador
                   ,a.BEDAT
                   ,g.name1
            having a.ebeln ";
            
            if(!empty($conFactura)){
                $sql .= " IN";
            }else{
                $sql .= " NOT IN";
            }
            
            $sql .= " 
            (
                select  d.ebeln 
                from SAPABAP1.rseg as d
                where a.ebeln = d.ebeln
                group by d.ebeln
            )
            
            order by a.ebeln desc
                   ,a.bukrs
                   ,e.butxt
                   ,a.kdate
                   ,a.kdatb
                   ,a.ernam
                   ,a.lifnr
                   ,a.ekgrp
                   ,f.eknam
                   ,a.ekorg
                   ,a.zzfinanciador
                   ,a.BEDAT
                   ,g.name1                   
                            ";           
            
            if (!empty($limite)) {
                $sql.=" LIMIT " . $limite;
            }
            
            //Helper::dd($sql, "consulta");
            //exit;
            $result = odbc_exec($this->db, $sql);
            //odbc_result_all($result,"class=table border=1");
            $resultados = array();
            if (!$result){
                throw new Exception("Error al consultar la base de datos!");
            }else{  
           
                while ($item = odbc_fetch_array($result)){
                                        
                    $ped = new SAPPedido();
                    $ped->setDocumentoComp($item["EBELN"]);
                    $ped->setSociedad($item["BUTXT"]);
                    
                    if ($item["KDATB"] != "00000000"){                    
                        $vigenciaDesde = DateTime::createFromFormat('Ymd', $item["KDATB"]);
                        $vigenciaHasta = DateTime::createFromFormat('Ymd', $item["KDATE"]);
                        $ped->setFechaValidacionFinal( $vigenciaDesde->format('d/m') ." a ". $vigenciaHasta->format('d/m') );                        
                    }
                    
                    $ped->setFechaDeDocumentoSAP($item["BEDAT"]);
                    $ped->setUsuario($item["ERNAM"]);
                    $ped->setProveedor($item["LIFNR"]);
                    $ped->setProveedorDesc($item["NAME1"]." - ". $item["LIFNR"]);
                    $ped->setOrgCompra($item["EKORG"]);
                    $ped->setGruCompra( utf8_encode($item["EKNAM"]));
                    $ped->setMontoTotal($item["SUMA"]);
                    $ped->setEstaLiberada(true);
                    $ped->setFinanciador($item["ZZFINANCIADOR"]);
                                        
                    // TODO: QUEDA PENDIENTE UNA CONSULTA GENERAL CON TODOS LOS NUEMROS DE PEDIDO 
                    // PARA INDICAR CUALES ESTAN CARGADOS Y CUALES NO
                    /*
                    
                     $facturaDAO = DAOFactory::getDAO('factura');
                     $factura =  $facturaDAO->buscarFacturaByNroPedido($item["EBELN"]);
                     $ped->setContabEnPortal( !(empty($factura->getFac_id())) );
                    
                    **/
                    if($traerDetalle){
                        $ped->setListPedidosDetalle($this->buscarDetallePedido($item["EBELN"],""));
                    }
                    
                    if(!empty($conFactura)){
                        $ped->setContabEnSAP(true);
                    }else{                        
                        $ped->setContabEnSAP(false);
                    }                                        
                    array_push($resultados, $ped);                   
                }
            }                       
            
            return $resultados;            
    }
           
    public function validaTieneMIGO($p_docu){


        $sql = "
            SELECT count(*) as CANT
            from SAPABAP1.EKKO
                INNER JOIN SAPABAP1.EKPO
                    ON SAPABAP1.EKKO.EBELN = SAPABAP1.EKPO.EBELN
                INNER JOIN SAPABAP1.EKBE          
                    ON SAPABAP1.EKBE.EBELN = SAPABAP1.EKPO.EBELN
                        AND SAPABAP1.EKBE.EBELP = SAPABAP1.EKPO.EBELP
                        AND SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "'
            WHERE SAPABAP1.EKKO.MANDT = '" . $this->getMandante() . "' 
                AND SAPABAP1.EKKO.EBELN =  " . $p_docu. "      
                AND SAPABAP1.EKPO.MANDT = '" . $this->getMandante() . "'            
                AND SAPABAP1.EKKO.FRGRL  <> 'X'  
                AND SAPABAP1.EKPO.LOEKZ NOT IN ('L','S')
                AND SAPABAP1.EKPO.EBELN  in (
                    SELECT SAPABAP1.EKBE.EBELN 
                    FROM SAPABAP1.EKBE          
                    WHERE SAPABAP1.EKBE.MANDT = '" . $this->getMandante() . "' 
                    AND SAPABAP1.EKBE.BEWTP  in ('Q', 'T')
                    AND SAPABAP1.EKKO.EBELN =  " . $p_docu. "       
                 )
                  

            ";
         
        if (empty($p_docu)) {            
            throw new Exception("No se cargo ningun filtro de busqueda");
        }
                        
        $result = odbc_exec($this->db, $sql);
        //odbc_result_all($result,"class=table border=1");
        
        $resultado =  false;                
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{            
            while ($item = odbc_fetch_object($result)){    
                if ($item->CANT > 0){
                    $resultado =  true;
                }                                                     
            }
        }       

        return $resultado;

    }
  
    public function validaFaltaVerFactEM($p_docu){


        $sql = "
            SELECT count(*) as CANT
            from SAPABAP1.EKKO
                INNER JOIN SAPABAP1.EKPO
                    ON SAPABAP1.EKKO.EBELN = SAPABAP1.EKPO.EBELN
            WHERE SAPABAP1.EKKO.MANDT = '" . $this->getMandante() . "' 
                AND SAPABAP1.EKPO.MANDT = '" . $this->getMandante() . "'            
                AND SAPABAP1.EKPO.WEBRE  <> 'X'  
                AND SAPABAP1.EKPO.LOEKZ NOT IN ('L','S')
            ";
         
        $filtro = "";
        $filtro = (!empty($p_docu) ? "AND SAPABAP1.EKKO.EBELN = " . $p_docu :"");        
        
        if (!empty($filtro)) {
            $sql.= $filtro;
        }else{
            throw new Exception("No se cargo ningun filtro de busqueda");
        }
                        
        $result = odbc_exec($this->db, $sql);
        
        //print del resultado para debug
        //odbc_result_all($result,"class=table border=1");
        
        $resultado =  false;                
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{            
            while ($item = odbc_fetch_object($result)){    
                if ($item->CANT > 0){
                    $resultado =  true;
                }                                                     
            }
        }
        return $resultado;
    }

    public function verEstadoPedido($p_docu){        
        
        $sql = "

	SELECT             	
	A.MANDT,
	A.EBELN,
	A.AEDAT,
	A.ERNAM,
	A.LIFNR,
	A.EKORG,
	A.EKGRP,
	A.BEDAT,
	B.BUKRS,
	B.WERKS,
	B.LGORT,
	B.EBELP,
	B.TXZ01,
	B.MATKL,
	B.MATNR,
	B.NETPR,
	B.MENGE,
	B.BANFN,
	B.BEDNR,
	B.BNFPO,
    CASE WHEN  S.BELNR IS NULL  THEN 'PENDIENTE' ELSE S.BELNR END BELNR ,
    CASE WHEN  S.XBLNR IS NULL  THEN 'PENDIENTE' ELSE S.XBLNR END XBLNR ,
    B.BEDNR,
    B.AFNAM
	FROM SAPABAP1.EKKO AS A
		INNER JOIN SAPABAP1.EKPO AS B
			ON A.EBELN = B.EBELN
       LEFT OUTER JOIN (
        SELECT D.XBLNR, D.BELNR, C.EBELN, C.EBELP FROM SAPABAP1.RSEG AS C
         INNER JOIN SAPABAP1.BKPF AS D
         ON  D.AWKEY = CONCAT(C.BELNR,C.GJAHR) ) AS S
            ON A.EBELN = S.EBELN AND B.EBELP = S.EBELP	

	WHERE A.MANDT =  '" . $this->getMandante() . "'
		AND B.MANDT =  '" . $this->getMandante() . "'		 

		AND A.FRGRL <> 'X'  
		AND B.LOEKZ NOT IN ('L','S')

              ";
        
        

         
        $filtro = "";
        $filtro = (!empty($p_docu) ? "AND A.EBELN = " . $p_docu :"");        
        
        if (!empty($filtro)) {
            $sql.= $filtro;
        }else{
            throw new Exception("No se cargo ningun filtro de busqueda");
        }                          
        
        //Helper::dd($sql  , "consulta");
        //exit;
        $result = odbc_exec($this->db, $sql);
        
        //print del resultado para debug
        //odbc_result_all($result,"class=table border=1");
        
        $resultados = array();                
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{            
            while ($item = odbc_fetch_object($result)){                                         
                array_push($resultados, $item);
            }
        }
        return $resultados;       
    }       

    /*
        *******************************
        filtros para buscar pedido
        *******************************
    **/
    
    public function buscarByProveedorConfactura($prov, $centro, $almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta){        
        return $this->buscarPedidos("", $prov, $limite, $centro, $almacen,true, false,$grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta) ;
    }
    
    public function buscarByProveedorPendiente($prov, $centro, $almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta){                
        return $this->buscarPedidos("", $prov, $limite, $centro, $almacen,false, false,$grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta) ;
    }
    
    public function buscarByCentroYAlmacenPendientes($centro, $almacen, $limite, $grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta,$proveedor){
        return $this->buscarPedidos("", $proveedor, $limite, $centro, $almacen,false, false,$grupoDeCompra,$fechaPrestDesde,$fechaPrestHasta) ;
    }
    
    public function buscarByNroDoc($docu){                
        $sapPedidos =  $this->buscarPedidos($docu, "", "", "", "", false, true, "", "", "");
        $sapPedido = "";        
        if (count($sapPedidos) > 0){
            $sapPedido =  $sapPedidos[0];
        }else{            
            //throw new Exception("El no existe número de documento SAP");
        }
        return $sapPedido;
    }

}

?>
