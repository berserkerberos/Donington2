<?php

class SAPProveedorDAO extends DAOGeneric {
    
    private $result;
    
    private $mandante;
    
    /**
     * @return mixed
     */
    public function getMandante()
    {
        return $this->mandante;
    }
    
    /**
     * @param mixed $mandante
     */
    public function setMandante($mandante)
    {
        $this->mandante = $mandante;
    }
    
    
    function __construct() {
        
        $iniFile = ROOT_PATH . "/backend/config/configDBSAP.ini";
        $data = parse_ini_file($iniFile, true);
        $con = "";
                
        $dsn = "Driver=".$data["DB_EJEMPLO"]["db_driver"].";ServerNode=" . $data["DB_EJEMPLO"]["db_string"] . ";Database=" . $data["DB_EJEMPLO"]["db_name"] ;
        $this->setMandante($data["DB_EJEMPLO"]["db_mandante"]);
        try {
            $con = odbc_connect($dsn, $data["DB_EJEMPLO"]["db_usr"] , $data["DB_EJEMPLO"]["db_pass"],SQL_CUR_USE_ODBC);
            $this->db =  $con;
        }catch (PDOException $e) {
            Helper::printDebugPanel("Error en la conexión con la DB, ","Error", true, true);
        }        
        
    }
    
   // TODO: poner en un archivo de configuracion los filtros fijos como mandantes
    private  function buscarUnProveedor($p_idSAP,$p_cuit,$p_idSAPArray){
        //filtrar los proveedores que esten de baja
        $sql = "SELECT STCD1 , LIFNR, NAME1, TELF1, STRAS, MCOD3, 
                 MIN(SMTP_ADDR) AS MAIL
                FROM SAPABAP1.LFA1
                    LEFT OUTER JOIN  SAPABAP1.ADR6 ON  LFA1.ADRNR = ADR6.ADDRNUMBER
                                
                WHERE MANDT='" . $this->getMandante() . "' ";
                
        
        $filtro = (!empty($p_idSAP) ? "AND SAPABAP1.LFA1.LIFNR = " . $p_idSAP :"");
        $filtro .= (!empty($p_idSAPArray) ? "AND SAPABAP1.LFA1.LIFNR in (" . implode(",",  $p_idSAPArray) . ")" :"");
        $filtro .= (!empty($p_cuit) ? "AND SAPABAP1.LFA1.STCD1 = '" . $p_cuit."'":" ");
                       
        if (!empty($filtro)) {
            $sql.= $filtro;
        }else{
            throw new Exception("No se cargo ningun filtro de busqueda");
        }                       
        
        $sql .= "GROUP BY STCD1 , LIFNR, NAME1, TELF1, STRAS, MCOD3 "; 
                       
        $result = odbc_exec($this->db, $sql);
        //odbc_result_all($result,"class=table border=1");
        
        $resultados = array();
        if (!$result){
            throw new Exception("Error al consultar la base de datos!");
        }else{                       
            while ($item = odbc_fetch_array($result)){            
                $prov = new SAPProveedor();
                $prov->setCuit($item["STCD1"]);
                $prov->setEmail($item["MAIL"]);
                $prov->setIdSAP($item["LIFNR"]);
                $prov->setRazonSoc(utf8_decode( $item["NAME1"]));
                $prov->setTel($item["TELF1"]);
                $prov->setDireccion($item["STRAS"]);
                $prov->setLocalidad($item["MCOD3"]);
                array_push($resultados, $prov);
            }
        }
        
        
        return $resultados;
    }
    
    public function buscarById($idSAP){
        return $this->buscarUnProveedor($idSAP, "","") ;                           
    }
    
    public function buscarByCUIT($cuit){
        //fintrar los proveedores que esten de baja        
        return $this->buscarUnProveedor("",  $cuit,"") ;
    }
    
    
    public function buscarVariosProveedores($idSAPArray){
        //fintrar los proveedores que esten de baja
        return $this->buscarUnProveedor("", "",$idSAPArray) ;
    }
    
    
}

?>
