<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once('phpmailer/PHPMailer.php');
require_once('phpmailer/Exception.php');
require_once('phpmailer/SMTP.php');

class MiSendMail {
              
    public static function getUrlNuevaClave() {

        $iniFile = ROOT_PATH . "/backend/config/configServer.ini";
        $data = parse_ini_file($iniFile, true);

        return $data["DOMINIO"]["ruta"] . "controllers/login.php?accion=NUEVO_USUARIO&clave=";
    }
    public static function enviarNuevaClave($emailTo,$emailToName,$emailFromName,$subject, $variables) {
        

        $iniFile = ROOT_PATH . "/backend/config/configServer.ini";
        $data = parse_ini_file($iniFile, true);

        $tmpResultado =  false;
        
        $mail = new PHPMailer(true);
        
        $smtpUsername = $data["MAIL"]["usuario"];
        $smtpPassword  = $data["MAIL"]["password"];
        $emailFrom =  $data["MAIL"]["from"];
        
        $mail->isSMTP();
        $mail->SMTPDebug = 0; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
        $mail->Host = $data["MAIL"]["server"]; // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
        $mail->Port = $data["MAIL"]["port"]; // TLS only
        //$mail->SMTPSecure = 'tls'; // ssl is depracated
        $mail->SMTPAuth = true;
        $mail->Username = $smtpUsername;
        $mail->Password = $smtpPassword;
        $mail->setFrom($emailFrom, $emailFromName);
        $mail->addAddress($emailTo, $emailToName);
        //$mail->addAddress("fede.barrios.99@gmail.com", "Barrios Eduardo Federico");
        $mail->Subject =  $subject ;
        
        
        $template = file_get_contents(   $_SERVER['DOCUMENT_ROOT'] . '/controllers/templates/nueva_clave.html');
        foreach ($variables as $key => $item){
            $template  = str_replace($key, $item, $template);
        }
        //prueba de html
        //echo "Resultado : </br>" . $template;
        $mail->msgHTML($template); //Read an HTML message body from an external file, convert referenced images to embedded,
        
        
        $mail->AltBody = 'No soporta mensajes de tipo HTML, pongase en contacto';
        // $mail->addAttachment('images/phpmailer_mini.png'); //Attach an image file
        
        try {
            $tmpsend = $mail->send();
            //$tmpsend = true;
            if(!$tmpsend){
                throw new Exception("Error al enviar: " . $mail->ErrorInfo ) ;
                $tmpResultado =  false;
            }else{
                $tmpResultado =  true;
            }
            
        } catch (Exception $e) {
            throw new Exception("Error general: " . $e->getMessage()) ;
            $tmpResultado =  false;
        }               
    }
    
    public static function enviarOCPendHonorarios($emailTo,$emailToName,$emailFromName,$subject, $variables) {
        
        
        $iniFile = ROOT_PATH . "/backend/config/configServer.ini";
        $data = parse_ini_file($iniFile, true);
        
        $tmpResultado =  false;
        
        $mail = new PHPMailer(true);
        
        $smtpUsername = $data["MAIL"]["usuario"];
        $smtpPassword  = $data["MAIL"]["password"];
        $emailFrom =  $data["MAIL"]["from"];
        
        $mail->isSMTP();
        $mail->SMTPDebug = 0; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
        $mail->Host = $data["MAIL"]["server"]; // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
        $mail->Port = $data["MAIL"]["port"]; // TLS only
        //$mail->SMTPSecure = 'tls'; // ssl is depracated
        $mail->SMTPAuth = true;
        $mail->Username = $smtpUsername;
        $mail->Password = $smtpPassword;
        $mail->setFrom($emailFrom, $emailFromName);
        $mail->addAddress($emailTo, $emailToName);
        //$mail->addAddress("fede.barrios.99@gmail.com", "Barrios Eduardo Federico");
        $mail->Subject =  $subject ;
        
        
        $template = file_get_contents(   $_SERVER['DOCUMENT_ROOT'] . '/controllers/templates/envioOCHonorarioPendiente.html');
        foreach ($variables as $key => $item){
            $template  = str_replace($key, $item, $template);
        }
        //prueba de html
        //echo "Resultado : </br>" . $template;
        $mail->msgHTML($template); //Read an HTML message body from an external file, convert referenced images to embedded,
        
        
        //$mail->AltBody = 'No soporta mensajes de tipo HTML, pongase en contacto';
        // $mail->addAttachment('images/phpmailer_mini.png'); //Attach an image file
        
        try {
            $tmpsend = $mail->send();
            //$tmpsend = true;
            if(!$tmpsend){
                throw new Exception("Error al enviar: " . $mail->ErrorInfo ) ;
                $tmpResultado =  false;
            }else{
                $tmpResultado =  true;
            }
            
        } catch (Exception $e) {
            throw new Exception("Error general: " . $e->getMessage()) ;
            $tmpResultado =  false;
        }
    }
    
}
