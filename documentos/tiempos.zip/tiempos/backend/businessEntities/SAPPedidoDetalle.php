<?php
class SAPPedidoDetalle {
    private $documentoComp;
    private $posicion;
    private $sociedad;
    private $almacen;
    private $detalle;
    private $cantidad;
    private $precio;
    private $codmaterial;
    private $cant_facturada;
    private $cant_PedDeEntrega;
    private $cant_PedDeFactura;
    
    /**
     * @return mixed
     */
    public function getCodMaterial()
    {
        return $this->codmaterial;
    }

    /**
     * @return mixed
     */
    public function getCant_facturada()
    {
        return $this->cant_facturada;
    }

    /**
     * @return mixed
     */
    public function getCant_PedDeEntrega()
    {
        return $this->cant_PedDeEntrega;
    }

    /**
     * @return mixed
     */
    public function getCant_PedDeFactura()
    {
        return $this->cant_PedDeFactura;
    }

    /**
     * @param mixed $codmaterial
     */
    public function setCodMaterial($codmaterial)
    {
        $this->codmaterial = $codmaterial;
    }

    /**
     * @param mixed $cant_facturada
     */
    public function setCant_facturada($cant_facturada)
    {
        $this->cant_facturada = $cant_facturada;
    }

    /**
     * @param mixed $cant_PedDeEntrega
     */
    public function setCant_PedDeEntrega($cant_PedDeEntrega)
    {
        $this->cant_PedDeEntrega = $cant_PedDeEntrega;
    }

    /**
     * @param mixed $cant_PedDeFactura
     */
    public function setCant_PedDeFactura($cant_PedDeFactura)
    {
        $this->cant_PedDeFactura = $cant_PedDeFactura;
    }

    /**
     * @return mixed
     */
    public function getDocumentoComp()
    {
        return $this->documentoComp;
    }

    /**
     * @param mixed $documentoComp
     */
    public function setDocumentoComp($documentoComp)
    {
        $this->documentoComp = $documentoComp;
    }

    /**
     * @return mixed
     */
    public function getPosicion()
    {
        return $this->posicion;
    }

    /**
     * @return mixed
     */
    public function getSociedad()
    {
        return $this->sociedad;
    }

    /**
     * @return mixed
     */
    public function getAlmacen()
    {
        return $this->almacen;
    }

    /**
     * @return mixed
     */
    public function getDetalle()
    {
        return $this->detalle;
    }

    /**
     * @return mixed
     */
    public function getCantidad()
    {
        return $this->cantidad;
    }

    /**
     * @return mixed
     */
    public function getPrecio()
    {
        return $this->precio;
    }

    /**
     * @param mixed $posicion
     */
    public function setPosicion($posicion)
    {
        $this->posicion = $posicion;
    }

    /**
     * @param mixed $sociedad
     */
    public function setSociedad($sociedad)
    {
        $this->sociedad = $sociedad;
    }

    /**
     * @param mixed $almacen
     */
    public function setAlmacen($almacen)
    {
        $this->almacen = $almacen;
    }

    /**
     * @param mixed $detalle
     */
    public function setDetalle($detalle)
    {
        $this->detalle = $detalle;
    }

    /**
     * @param mixed $cantidad
     */
    public function setCantidad($cantidad)
    {
        $this->cantidad = $cantidad;
    }

    /**
     * @param mixed $precio
     */
    public function setPrecio($precio)
    {
        $this->precio = $precio;
    }
    
}