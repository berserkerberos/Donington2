<?php 

class Proveedor {
    private $CUIT;
    private $clave;
    private $idSAP;
    private $razonSoc;
    private $email;
    private $tel;
    private $tipoProve;
    private $tipoProveId;
    private $estado;
    private $id;
    private $centroAlmacenAdmin;
    
    /**
     * @return mixed
     */
    public function getCentroAlmacenAdmin()
    {
        return $this->centroAlmacenAdmin;
    }
    
    public function getGruposDeCompra()
    {
        return  [
            [
                "CLAVE" => "S13",
                "VALOR" => "Honorarios"
            ],
            [
                "CLAVE" => "S01",
                "VALOR" => "Medicación Ambulat"
            ],
            [
                "CLAVE" => "S03",
                "VALOR" => "Prótesis"
            ],
            [
                "CLAVE" => "S04",
                "VALOR" => "Órtesis"
            ]
        ];
    }
    

    /**
     * @param mixed $centroAlmacenAdmin
     */
    public function setCentroAlmacenAdmin($centroAlmacenAdmin)
    {
        $this->centroAlmacenAdmin = $centroAlmacenAdmin;
    }

    /**
     * @return mixed
     */
    public function getTipoProveId()
    {
        return $this->tipoProveId;
    }

    /**
     * @param mixed $tipoProveId
     */
    public function setTipoProveId($tipoProveId)
    {
        $this->tipoProveId = $tipoProveId;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getCUIT()
    {
        return $this->CUIT;
    }

    /**
     * @return mixed
     */
    public function getClave()
    {
        return $this->clave;
    }

    /**
     * @return mixed
     */
    public function getIdSAP()
    {
        return $this->idSAP;
    }

    /**
     * @return mixed
     */
    public function getRazonSoc()
    {
        return $this->razonSoc;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @return mixed
     */
    public function getTel()
    {
        return $this->tel;
    }

    /**
     * @return mixed
     */
    public function getTipoProve()
    {
        return $this->tipoProve;
    }

    /**
     * @return mixed
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * @param mixed $CUIT
     */
    public function setCUIT($CUIT)
    {
        $this->CUIT = $CUIT;
    }

    /**
     * @param mixed $clave
     */
    public function setClave($clave)
    {
        $this->clave = $clave;
    }

    /**
     * @param mixed $idSAP
     */
    public function setIdSAP($idSAP)
    {
        $this->idSAP = $idSAP;
    }

    /**
     * @param mixed $razonSoc
     */
    public function setRazonSoc($razonSoc)
    {
        $this->razonSoc = $razonSoc;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @param mixed $tel
     */
    public function setTel($tel)
    {
        $this->tel = $tel;
    }

    /**
     * @param mixed $tipoProve
     */
    public function setTipoProve($tipoProve)
    {
        $this->tipoProve = $tipoProve;
    }

    /**
     * @param mixed $estado
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;
    }

    
}
