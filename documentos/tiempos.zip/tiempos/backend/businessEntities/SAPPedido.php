<?php 

class SAPPedido {        
    private $documentoComp;
    private $sociedad;       
    private $fechaValidacionFinal;
    private $usuario;
    private $proveedor;
    private $gruCompra;
    private $orgCompra;
    private $montoTotal;
    private $listPedidosDetalle;
    private $contabEnPortal;
    private $contabEnSAP;
    private $estaLiberada;
    private $financiador;
    private $fechaDeDocumentoSAP;    
    private $proveedorDesc;
    
    /**
     * @return mixed
     */
    public function getProveedorDesc()
    {
        return $this->proveedorDesc;
    }

    /**
     * @param mixed $proveedorDesc
     */
    public function setProveedorDesc($proveedorDesc)
    {
        $this->proveedorDesc = $proveedorDesc;
    }

    /**
     * @return mixed
     */
    public function getFechaDeDocumentoSAP()
    {
        return $this->fechaDeDocumentoSAP;
    }

    /**
     * @param mixed $fechaDeDocumentoSAP
     */
    public function setFechaDeDocumentoSAP($fechaDeDocumentoSAP)
    {
        $this->fechaDeDocumentoSAP = $fechaDeDocumentoSAP;
    }

    /**
     * @return mixed
     */
    public function getFinanciador()
    {
        return $this->financiador;
    }

    /**
     * @param mixed $financiador
     */
    public function setFinanciador($financiador)
    {
        $this->financiador = $financiador;
    }

    /**
     * @return mixed
     */
    public function getEstaLiberada()
    {
        return $this->estaLiberada;
    }

    /**
     * @param mixed $estaLiberada
     */
    public function setEstaLiberada($estaLiberada)
    {
        $this->estaLiberada = $estaLiberada;
    }

    /**
     * @return mixed
     */
    public function getContabEnPortal()
    {
        return $this->contabEnPortal;
    }

    /**
     * @return mixed
     */
    public function getContabEnSAP()
    {
        return $this->contabEnSAP;
    }

    /**
     * @param mixed $contabEnPortal
     */
    public function setContabEnPortal($contabEnPortal)
    {
        $this->contabEnPortal = $contabEnPortal;
    }

    /**
     * @param mixed $contabEnSAP
     */
    public function setContabEnSAP($contabEnSAP)
    {
        $this->contabEnSAP = $contabEnSAP;
    }

    /**
     * @return mixed
     */
    public function getFechaValidacionFinal()
    {
        return $this->fechaValidacionFinal;
    }

    /**
     * @param mixed $fechaValidacionFinal
     */
    public function setFechaValidacionFinal($fechaValidacionFinal)
    {
        $this->fechaValidacionFinal = $fechaValidacionFinal;
    }

    /**
     * @return mixed
     */
    public function getListPedidosDetalle()
    {
        return $this->listPedidosDetalle;
    }

    /**
     * @param mixed $listPedidosDetalle
     */
    public function setListPedidosDetalle($listPedidosDetalle)
    {
        $this->listPedidosDetalle = $listPedidosDetalle;
    }

    /**
     * @return mixed
     */
    public function getDocumentoComp()
    {
        return $this->documentoComp;
    }

    /**
     * @param mixed $documentoComp
     */
    public function setDocumentoComp($documentoComp)
    {
        $this->documentoComp = $documentoComp;
    }

    /**
     * @return mixed
     */
    public function getCondDocumento()
    {
        return $this->condDocumento;
    }

    /**
     * @return mixed
     */
    public function getSociedad()
    {
        return $this->sociedad;
    }

    /**
     * @return mixed
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * @return mixed
     */
    public function getProveedor()
    {
        return $this->proveedor;
    }

    /**
     * @return mixed
     */
    public function getGruCompra()
    {
        return $this->gruCompra;
    }

    /**
     * @return mixed
     */
    public function getOrgCompra()
    {
        return $this->orgCompra;
    }

    /**
     * @return mixed
     */
    public function getMontoTotal()
    {
        return $this->montoTotal;
    }

    /**
     * @param mixed $sociedad
     */
    public function setSociedad($sociedad)
    {
        $this->sociedad = $sociedad;
    }

    /**
     * @param mixed $usuario
     */
    public function setUsuario($usuario)
    {
        $this->usuario = $usuario;
    }

    /**
     * @param mixed $proveedor
     */
    public function setProveedor($proveedor)
    {
        $this->proveedor = $proveedor;
    }

    /**
     * @param mixed $gruCompra
     */
    public function setGruCompra($gruCompra)
    {
        $this->gruCompra = $gruCompra;
    }

    /**
     * @param mixed $orgCompra
     */
    public function setOrgCompra($orgCompra)
    {
        $this->orgCompra = $orgCompra;
    }

    /**
     * @param mixed $montoTotal
     */
    public function setMontoTotal($montoTotal)
    {
        $this->montoTotal = $montoTotal;
    }
      
}


?>