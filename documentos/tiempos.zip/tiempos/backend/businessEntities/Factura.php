<?php

class Factura {

	private $fac_id;
	private $fac_pedSap;
    private $fac_anoSap;
    private $fac_TipoFac;
    private $fac_nroFact;
    private $fac_fechaEmi;    
    private $fac_monto; 
    private $fac_provSap;
    private $fac_cae;
    private $fac_adjunto;
    private $fac_estado;
    private $fac_migoSap;
    private $fac_miroSap;
    private $fac_observac;
    private $fac_fecIngreso;
    private $fac_iva;
    
    
    private $estadoDesc;
    private $ProveedorObj;
    private $lisSapPedidoDetalle;
    private $pendienControl;

    private $fac_provSapDesc;
    
    
    

    /**
     * @param mixed $ProveedorObj
     */
    public function setProveedorObj($ProveedorObj)
    {
        $this->ProveedorObj = $ProveedorObj;
    }

    /**
     * @return mixed
     */
    public function getFac_provSapDesc()
    {
        return $this->fac_provSapDesc;
    }

    /**
     * @param mixed $fac_provSapDesc
     */
    public function setFac_provSapDesc($fac_provSapDesc)
    {
        $this->fac_provSapDesc = $fac_provSapDesc;
    }

    /**
     * @return mixed
     */
    public function getPendienControl()
    {
        return $this->pendienControl;
    }

    /**
     * @param mixed $pendienControl
     */
    public function setPendienControl($pendienControl)
    {
        $this->pendienControl = $pendienControl;
    }

    /**
     * @return mixed
     */
    public function getFac_iva()
    {
        return $this->fac_iva;
    }

    /**
     * @param mixed $fac_iva
     */
    public function setFac_iva($fac_iva)
    {
        $this->fac_iva = $fac_iva;
    }

    /**
     * @return mixed
     */
    public function getFac_fecIngreso()
    {
        return $this->fac_fecIngreso;
    }

    /**
     * @param mixed $fac_fecIngreso
     */
    public function setFac_fecIngreso($fac_fecIngreso)
    {
        $this->fac_fecIngreso = $fac_fecIngreso;
    }

    /**
     * @return mixed
     */
    public function getLisSapPedidoDetalle()
    {
        return $this->lisSapPedidoDetalle;
    }

    /**
     * @param mixed $lisSapPedidoDetalle
     */
    public function setLisSapPedidoDetalle($lisSapPedidoDetalle)
    {
        $this->lisSapPedidoDetalle = $lisSapPedidoDetalle;
    }

    /**
     * @return mixed
     */
    public function getEstadoDesc()
    {
        return $this->estadoDesc;
    }

    /**
     * @return mixed
     */
    public function getProveedorObj()
    {        
        return $this->ProveedorObj ;
    }

    /**
     * @param mixed $estadoDesc
     */
    public function setEstadoDesc($estadoDesc)
    {
        $this->estadoDesc = $estadoDesc;
    }


    /**
     * @return mixed
     */
    public function getFac_id()
    {
        return $this->fac_id;
    }

    /**
     * @return mixed
     */
    public function getFac_pedSap()
    {
        return $this->fac_pedSap;
    }

    /**
     * @return mixed
     */
    public function getFac_anoSap()
    {
        return $this->fac_anoSap;
    }

    /**
     * @return mixed
     */
    public function getFac_TipoFac()
    {
        return $this->fac_TipoFac;
    }

    /**
     * @return mixed
     */
    public function getFac_nroFact()
    {
        return $this->fac_nroFact;
    }

    /**
     * @return mixed
     */
    public function getFac_fechaEmi()
    {
        return $this->fac_fechaEmi;
    }

    /**
     * @return mixed
     */
    public function getFac_monto()
    {
        return $this->fac_monto;
    }

    /**
     * @return mixed
     */
    public function getFac_provSap()
    {
        return $this->fac_provSap;
    }

    /**
     * @return mixed
     */
    public function getFac_cae()
    {
        return $this->fac_cae;
    }

    /**
     * @return mixed
     */
    public function getFac_adjunto()
    {
        return $this->fac_adjunto;
    }

    /**
     * @return mixed
     */
    public function getFac_estado()
    {
        return $this->fac_estado;
    }

    /**
     * @return mixed
     */
    public function getFac_migoSap()
    {
        return $this->fac_migoSap;
    }

    /**
     * @return mixed
     */
    public function getFac_miroSap()
    {
        return $this->fac_miroSap;
    }

    /**
     * @return mixed
     */
    public function getFac_observac()
    {
        return $this->fac_observac;
    }

    /**
     * @param mixed $fac_id
     */
    public function setFac_id($fac_id)
    {
        $this->fac_id = $fac_id;
    }

    /**
     * @param mixed $fac_pedSap
     */
    public function setFac_pedSap($fac_pedSap)
    {
        $this->fac_pedSap = $fac_pedSap;
    }

    /**
     * @param mixed $fac_anoSap
     */
    public function setFac_anoSap($fac_anoSap)
    {
        $this->fac_anoSap = $fac_anoSap;
    }

    /**
     * @param mixed $fac_TipoFac
     */
    public function setFac_TipoFac($fac_TipoFac)
    {
        $this->fac_TipoFac = $fac_TipoFac;
    }

    /**
     * @param mixed $fac_nroFact
     */
    public function setFac_nroFact($fac_nroFact)
    {
        $this->fac_nroFact = $fac_nroFact;
    }

    /**
     * @param mixed $fac_fechaEmi
     */
    public function setFac_fechaEmi($fac_fechaEmi)
    {
        $this->fac_fechaEmi = $fac_fechaEmi;
    }

    /**
     * @param mixed $fac_monto
     */
    public function setFac_monto($fac_monto)
    {
        $this->fac_monto = $fac_monto;
    }

    /**
     * @param mixed $fac_provSap
     */
    public function setFac_provSap($fac_provSap)
    {
        $this->fac_provSap = $fac_provSap;
    }

    /**
     * @param mixed $fac_cae
     */
    public function setFac_cae($fac_cae)
    {
        $this->fac_cae = $fac_cae;
    }

    /**
     * @param mixed $fac_adjunto
     */
    public function setFac_adjunto($fac_adjunto)
    {
        $this->fac_adjunto = $fac_adjunto;
    }

    /**
     * @param mixed $fac_estado
     */
    public function setFac_estado($fac_estado)
    {
        $this->fac_estado = $fac_estado;
    }

    /**
     * @param mixed $fac_migoSap
     */
    public function setFac_migoSap($fac_migoSap)
    {
        $this->fac_migoSap = $fac_migoSap;
    }

    /**
     * @param mixed $fac_miroSap
     */
    public function setFac_miroSap($fac_miroSap)
    {
        $this->fac_miroSap = $fac_miroSap;
    }

    /**
     * @param mixed $fac_observac
     */
    public function setFac_observac($fac_observac)
    {
        $this->fac_observac = $fac_observac;
    }

    public function __construct() {

    }
    

	
}

?>
