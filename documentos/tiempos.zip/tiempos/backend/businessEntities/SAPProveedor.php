<?php 


class SAPProveedor {
    private $CUIT;    
    private $idSAP;
    private $razonSoc;
    private $email;
    private $tel;    
    private $estado;
    private $direccion;
    private $localidad;
    
    /**
     * @return mixed
     */
    public function getDireccion()
    {
        return $this->direccion;
    }

    /**
     * @return mixed
     */
    public function getLocalidad()
    {
        return $this->localidad;
    }

    /**
     * @param mixed $direccion
     */
    public function setDireccion($direccion)
    {
        $this->direccion = $direccion;
    }

    /**
     * @param mixed $localidad
     */
    public function setLocalidad($localidad)
    {
        $this->localidad = $localidad;
    }

    /**
     * @return mixed
     */
    public function getCuit()
    {
        return $this->cuit;
    }

    /**
     * @return mixed
     */
    public function getIdSAP()
    {
        return $this->idSAP;
    }

    /**
     * @return mixed
     */
    public function getRazonSoc()
    {
        return $this->razonSoc;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @return mixed
     */
    public function getTel()
    {
        return $this->tel;
    }

    /**
     * @return mixed
     */
    public function getEstado()
    {
        return $this->estado;
    }

    /**
     * @param mixed $cuit
     */
    public function setCuit($cuit)
    {
        $this->cuit = $cuit;
    }

    /**
     * @param mixed $idSAP
     */
    public function setIdSAP($idSAP)
    {
        $this->idSAP = $idSAP;
    }

    /**
     * @param mixed $razonSoc
     */
    public function setRazonSoc($razonSoc)
    {
        $this->razonSoc = $razonSoc;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @param mixed $tel
     */
    public function setTel($tel)
    {
        $this->tel = $tel;
    }

    /**
     * @param mixed $estado
     */
    public function setEstado($estado)
    {
        $this->estado = $estado;
    }
    
}


?>