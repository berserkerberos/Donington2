<?php 

//phpinfo();
header('location: controllers/reloj.php');
/*
for($i = 0; $i <= 100; $i++){	
	echo "Prueba :" . $i . "</br>";
}
**/
exit;
?>
